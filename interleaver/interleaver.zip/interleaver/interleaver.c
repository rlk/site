/*    Copyright (C) 2008 Robert Kooima                                       */
/*                                                                           */
/*    Interleaver is free software; you can redistribute it and/or modify    */
/*    it  under the terms  of the  GNU Lesser  General Public  License as    */
/*    published by the Free Software  Foundation; either version 2 of the    */
/*    License, or (at your option) any later version                         */
/*                                                                           */
/*    This program is distributed in the hope that it will be useful, but    */
/*    WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of    */
/*    MERCHANTABILITY or  FITNESS FOR A PARTICULAR PURPOSE.   See the GNU    */
/*    Lesser General Public License for more details.                        */

#include <GL/glew.h>

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "interleaver.h"

/*---------------------------------------------------------------------------*/

struct il_context
{
    int eyes;

    /* Shader and program state. */

    GLuint  shader_vert;
    GLuint  shader_frag;
    GLuint  program;

    /* Program uniform locations. */

    GLint   uni_eyes;
    GLint   uni_size;
    GLint   uni_offset;
    GLint   uni_quality;

    GLint  *uni_coeff;
    GLint  *uni_cycle;
    GLint  *uni_step0;
    GLint  *uni_step1;
    GLint  *uni_step2;
    GLint  *uni_step3;
    GLint  *uni_depth;

    /* Render target textures, framebuffer, screen vertex buffer. */

    GLuint  buffer_depth;
    GLuint *buffer_color;
    GLuint *buffer_frame;
    GLuint  buffer_vertex;
};

/*---------------------------------------------------------------------------*/

static void normalize(float *v)
{
    float k = 1.0f / (float) sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);

    v[0] *= k;
    v[1] *= k;
    v[2] *= k;
}

static float distance(const float *a, const float *b)
{
    float d[3];

    d[0] = b[0] - a[0];
    d[1] = b[1] - a[1];
    d[2] = b[2] - a[2];

    return (float) sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
}

static void translation(float *M, float x, float y, float z)
{
    M[ 0] = 1.0f; M[ 4] = 0.0f; M[ 8] = 0.0f; M[12] =    x;
    M[ 1] = 0.0f; M[ 5] = 1.0f; M[ 9] = 0.0f; M[13] =    y;
    M[ 2] = 0.0f; M[ 6] = 0.0f; M[10] = 1.0f; M[14] =    z;
    M[ 3] = 0.0f; M[ 7] = 0.0f; M[11] = 0.0f; M[15] = 1.0f;
}

static void zrotation(float *M, float a)
{
    const float c = (float) cos(M_PI * a / 180.0);
    const float s = (float) sin(M_PI * a / 180.0);

    M[ 0] =    c; M[ 4] =   -s; M[ 8] = 0.0f; M[12] = 0.0f;
    M[ 1] =    s; M[ 5] =    c; M[ 9] = 0.0f; M[13] = 0.0f;
    M[ 2] = 0.0f; M[ 6] = 0.0f; M[10] = 1.0f; M[14] = 0.0f;
    M[ 3] = 0.0f; M[ 7] = 0.0f; M[11] = 0.0f; M[15] = 1.0f;
}

static void scaling(float *M, float x, float y, float z)
{
    M[ 0] =    x; M[ 4] = 0.0f; M[ 8] = 0.0f; M[12] = 0.0f;
    M[ 1] = 0.0f; M[ 5] =    y; M[ 9] = 0.0f; M[13] = 0.0f;
    M[ 2] = 0.0f; M[ 6] = 0.0f; M[10] =    z; M[14] = 0.0f;
    M[ 3] = 0.0f; M[ 7] = 0.0f; M[11] = 0.0f; M[15] = 1.0f;
}

static void multiply(float *M, const float *N, const float *O)
{
    M[ 0] = N[ 0] * O[ 0] + N[ 4] * O[ 1] + N[ 8] * O[ 2] + N[12] * O[ 3];
    M[ 1] = N[ 1] * O[ 0] + N[ 5] * O[ 1] + N[ 9] * O[ 2] + N[13] * O[ 3];
    M[ 2] = N[ 2] * O[ 0] + N[ 6] * O[ 1] + N[10] * O[ 2] + N[14] * O[ 3];
    M[ 3] = N[ 3] * O[ 0] + N[ 7] * O[ 1] + N[11] * O[ 2] + N[15] * O[ 3];

    M[ 4] = N[ 0] * O[ 4] + N[ 4] * O[ 5] + N[ 8] * O[ 6] + N[12] * O[ 7];
    M[ 5] = N[ 1] * O[ 4] + N[ 5] * O[ 5] + N[ 9] * O[ 6] + N[13] * O[ 7];
    M[ 6] = N[ 2] * O[ 4] + N[ 6] * O[ 5] + N[10] * O[ 6] + N[14] * O[ 7];
    M[ 7] = N[ 3] * O[ 4] + N[ 7] * O[ 5] + N[11] * O[ 6] + N[15] * O[ 7];

    M[ 8] = N[ 0] * O[ 8] + N[ 4] * O[ 9] + N[ 8] * O[10] + N[12] * O[11];
    M[ 9] = N[ 1] * O[ 8] + N[ 5] * O[ 9] + N[ 9] * O[10] + N[13] * O[11];
    M[10] = N[ 2] * O[ 8] + N[ 6] * O[ 9] + N[10] * O[10] + N[14] * O[11];
    M[11] = N[ 3] * O[ 8] + N[ 7] * O[ 9] + N[11] * O[10] + N[15] * O[11];

    M[12] = N[ 0] * O[12] + N[ 4] * O[13] + N[ 8] * O[14] + N[12] * O[15];
    M[13] = N[ 1] * O[12] + N[ 5] * O[13] + N[ 9] * O[14] + N[13] * O[15];
    M[14] = N[ 2] * O[12] + N[ 6] * O[13] + N[10] * O[14] + N[14] * O[15];
    M[15] = N[ 3] * O[12] + N[ 7] * O[13] + N[11] * O[14] + N[15] * O[15];
}

static void perspective(float *P, float l, float r,
                                  float b, float t,
                                  float n, float f)
{
    P[ 0] = (2.0f * n) / (r - l);
    P[ 1] =  0.0f;
    P[ 2] =  0.0f;
    P[ 3] =  0.0f;
    P[ 4] =  0.0f;
    P[ 5] = (2.0f * n) / (t - b);
    P[ 6] =  0.0f;
    P[ 7] =  0.0f;
    P[ 8] =  (r + l) / (r - l);
    P[ 9] =  (t + b) / (t - b);
    P[10] = -(f + n) / (f - n);
    P[11] = -1.0f;
    P[12] =  0.0f;
    P[13] =  0.0f;
    P[14] = -2.0f * f * n / (f - n);
    P[15] =  0.0f;
}

/*---------------------------------------------------------------------------*/

static int file_open(const char *name)
{
    /* Return a readable descriptor for the named file. */

#ifndef _WIN32
    return open(name, O_RDONLY);
#else
    return open(name, O_RDONLY | O_BINARY);
#endif
}

static int file_size(const char *name)
{
    /* Return the size of the named file in bytes. */

    struct stat buf;

    if (stat(name, &buf) == 0)
        return (int) buf.st_size;
    else
        return 0;
}

static char *file_load(const char *name)
{
    /* Load the named file into a newly-allocated buffer. */

    int   sz;
    int   fd;
    char *buf = NULL;

    if ((sz = file_size(name)))
    {
        if ((fd = file_open(name)) != -1)
        {
            if ((buf = (char *) calloc(sz + 1, 1)))
            {
                read(fd, buf, sz);
            }
            close(fd);
        }
    }
    return buf;
}

/*---------------------------------------------------------------------------*/

int il_check_error(void)
{
    const char *s = NULL;

    switch (glGetError())
    {
    case  GL_NO_ERROR:
        return 1;

    case  GL_INVALID_ENUM:
        s = "Invalid enumerant";
        break;
    case  GL_INVALID_VALUE:
        s = "Invalid value";
        break;
    case  GL_INVALID_OPERATION:
        s = "Invalid operation";
        break;
    case  GL_STACK_OVERFLOW:
        s = "Stack overflow";
        break;
    case  GL_OUT_OF_MEMORY:
        s = "Out of memory";
        break;
    case  GL_TABLE_TOO_LARGE:
        s = "Table too large";
        break;
    default:
        s = "Unknown";
        break;
    }

    fprintf(stderr, "OpenGL Error: %s\n", s);

    return 0;
}

int il_check_framebuffer(void)
{
    const char *s = NULL;

    switch (glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT))
    {
    case    GL_FRAMEBUFFER_COMPLETE_EXT:
        return 1;

    case    GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT:
        s = "Framebuffer incomplete attachment";
        break;
    case    GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT:
        s = "Framebuffer incomplete missing attachment";
        break;
    case    GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT:
        s = "Framebuffer incomplete dimensions";
        break;
    case    GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT:
        s = "Framebuffer incomplete formats";
        break;
    case    GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT:
        s = "Framebuffer incomplete draw buffer";
        break;
    case    GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT:
        s = "Framebuffer incomplete read buffer";
        break;
    case    GL_FRAMEBUFFER_UNSUPPORTED_EXT:
        s = "Framebuffer unsupported";
        break;
    default:
        s = "Framebuffer error";
        break;
    }

    fprintf(stderr, "OpenGL Error: %s\n", s);

    return 0;
}

int il_check_shader_log(GLuint shader)
{
    GLchar *log = NULL;
    GLint   val = 0;
    GLint   len = 0;

    /* Check the shader compile status.  If failed, print the log. */

    glGetShaderiv(shader, GL_COMPILE_STATUS,  &val);
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);

    if (val == 0)
    {
        if ((log = (GLchar *) calloc(len + 1, 1)))
        {
            glGetShaderInfoLog(shader, len, NULL, log);

            fprintf(stderr, "OpenGL Shader Error:\n%s", log);
            free(log);
        }
        return 0;
    }
    return 1;
}

int il_check_program_log(GLuint program)
{
    GLchar *log = NULL;
    GLint   val = 0;
    GLint   len = 0;

    /* Check the program link status.  If failed, print the log. */

    glGetProgramiv(program, GL_LINK_STATUS,     &val);
    glGetProgramiv(program, GL_INFO_LOG_LENGTH, &len);

    if (val == 0)
    {
        if ((log = (GLchar *) calloc(len + 1, 1)))
        {
            glGetProgramInfoLog(program, len, NULL, log);

            fprintf(stderr, "OpenGL Program Error:\n%s", log);
            free(log);
        }
        return 0;
    }
    return 1;
}

/*---------------------------------------------------------------------------*/

static void init_color(GLenum T, GLuint o, int w, int h)
{
    /* Set the default state of a color buffer texture. */

    glBindTexture(T, o);
    {
        glTexImage2D(T, 0, GL_RGBA8, w, h, 0,
                     GL_RGBA, GL_INT, NULL);

        glTexParameteri(T, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(T, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(T, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(T, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    glBindTexture(T, 0);
}

static void init_depth(GLenum T, GLuint o, int w, int h)
{
    /* Set the default state of a depth buffer texture. */

    glBindTexture(T, o);
    {
        glTexImage2D(T, 0, GL_DEPTH_COMPONENT24, w, h, 0,
                     GL_DEPTH_COMPONENT, GL_INT, NULL);

        glTexParameteri(T, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(T, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(T, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(T, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    glBindTexture(T, 0);
}

static int init_frame(GLuint frame, GLuint color, GLuint depth)
{
    /* Bind the color and depth textures to the framebuffer.  Check it. */

    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, frame);
    
    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT,
                              GL_COLOR_ATTACHMENT0_EXT,
                              GL_TEXTURE_RECTANGLE_ARB, color, 0);
    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT,
                              GL_DEPTH_ATTACHMENT_EXT, 
                              GL_TEXTURE_RECTANGLE_ARB, depth, 0);

    return il_check_framebuffer();
}

static GLuint init_shader(GLenum type, const char *name)
{
    /* Load the named shader source file. */

    GLuint  shader = 0;
    GLchar *text   = NULL;

    if ((text = file_load(name)))
    {
        /* Compile a new shader with the given source. */

        shader = glCreateShader(type);

        glShaderSource (shader, 1, (const GLchar **) &text, NULL);
        glCompileShader(shader);

        /* If the shader is invalid, delete it. */

        if (il_check_shader_log(shader) == 0)
        {
            glDeleteShader(shader);
            shader = 0;
        }

        /* Release the source buffer. */

        free(text);
    }
    return shader;
}

/*---------------------------------------------------------------------------*/

static int il_init_buffers(struct il_context *ctx, int w, int h)
{
    int i;

    if ((ctx->buffer_color = (GLuint *) calloc(ctx->eyes, sizeof (GLuint))) &&
        (ctx->buffer_frame = (GLuint *) calloc(ctx->eyes, sizeof (GLuint))))
    {
        /* Generate a framebuffer, N color buffers, and a depth buffer. */

        glGenFramebuffersEXT(ctx->eyes, ctx->buffer_frame);
        
        glGenTextures(ctx->eyes, ctx->buffer_color);
        glGenTextures(1,        &ctx->buffer_depth);

        /* Initialize the color and depth buffer textures. */

        init_depth(GL_TEXTURE_RECTANGLE_ARB, ctx->buffer_depth, w, h);

        for (i = 0; i < ctx->eyes; ++i)
        {
            init_color(GL_TEXTURE_RECTANGLE_ARB, ctx->buffer_color[i], w, h);
            init_frame(ctx->buffer_frame[i],
                       ctx->buffer_color[i],
                       ctx->buffer_depth);
        }
        return 1;
    }
    return 0;
}

static void il_fini_buffers(struct il_context *ctx)
{
    /* Delete the frame buffers and textures. */

    glDeleteTextures(1, &ctx->buffer_depth);

    if (ctx->buffer_color)
    {
        glDeleteTextures(ctx->eyes, ctx->buffer_color);
        free(ctx->buffer_color);
    }

    if (ctx->buffer_frame)
    {
        glDeleteFramebuffersEXT(ctx->eyes, ctx->buffer_frame);
        free(ctx->buffer_frame);
    }
}

static void il_bind_buffers(const struct il_context *ctx)
{
    int i;

    for (i = ctx->eyes - 1; i >= 0; --i)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture  (GL_TEXTURE_RECTANGLE_ARB, ctx->buffer_color[i]);
    }

    glActiveTexture(GL_TEXTURE0);
}

static void il_free_buffers(const struct il_context *ctx)
{
    int i;

    for (i = ctx->eyes - 1; i >= 0; --i)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture  (GL_TEXTURE_RECTANGLE_ARB, 0);
    }

    glActiveTexture(GL_TEXTURE0);
}

/*---------------------------------------------------------------------------*/

static int il_init_shaders(struct il_context *ctx, const char *vert_name,
                                                   const char *frag_name)
{
    /* Load and compile the shader source files. */

    if ((ctx->shader_vert = init_shader(GL_VERTEX_SHADER,   vert_name)) &&
        (ctx->shader_frag = init_shader(GL_FRAGMENT_SHADER, frag_name)))
    {
        /* Link them to a new program object. */

        ctx->program = glCreateProgram();

        glAttachShader(ctx->program, ctx->shader_vert);
        glAttachShader(ctx->program, ctx->shader_frag);

        glLinkProgram(ctx->program);

        if (il_check_program_log(ctx->program))
            return 1;
    }
    return 0;
}

static void il_fini_shaders(struct il_context *ctx)
{
    /* Delete shader and program objects. */

    glDeleteShader(ctx->shader_vert);
    glDeleteShader(ctx->shader_frag);

    glDeleteProgram(ctx->program);
}

/*---------------------------------------------------------------------------*/

static char *array_i(char *str, const char *name, int i)
{
    /* Print the name of array element i to the string. */

    sprintf(str, "%s[%d]", name, i);
    return  str;
}
static int il_init_uniforms(struct il_context *ctx)
{
    GLuint P = ctx->program;

    char s[32];
    int  i;

    /* Extract program uniform locations for run-time use. */

    ctx->uni_eyes    = glGetUniformLocation(P, "eyes");
    ctx->uni_size    = glGetUniformLocation(P, "size");
    ctx->uni_offset  = glGetUniformLocation(P, "offset");
    ctx->uni_quality = glGetUniformLocation(P, "quality");

    /* Set the values of all known constant uniforms. */

    glUseProgram(P);
    {
        for (i = 0; i < ctx->eyes; ++i)
            glUniform1i(glGetUniformLocation(P, array_i(s, "image", i)), i);

        glUniform1i(ctx->uni_eyes, ctx->eyes);
    }
    glUseProgram(0);

    /* Extract the location of all transform vector array element. */

    if ((ctx->uni_coeff = (GLint *) calloc(ctx->eyes, sizeof (GLint))) &&
        (ctx->uni_cycle = (GLint *) calloc(ctx->eyes, sizeof (GLint))) &&
        (ctx->uni_step0 = (GLint *) calloc(ctx->eyes, sizeof (GLint))) &&
        (ctx->uni_step1 = (GLint *) calloc(ctx->eyes, sizeof (GLint))) &&
        (ctx->uni_step2 = (GLint *) calloc(ctx->eyes, sizeof (GLint))) &&
        (ctx->uni_step3 = (GLint *) calloc(ctx->eyes, sizeof (GLint))) &&
        (ctx->uni_depth = (GLint *) calloc(ctx->eyes, sizeof (GLint))))

    {
        for (i = 0; i < ctx->eyes; ++i)
        {
            ctx->uni_coeff[i] = glGetUniformLocation(P, array_i(s, "coeff", i));
            ctx->uni_cycle[i] = glGetUniformLocation(P, array_i(s, "cycle", i));
            ctx->uni_step0[i] = glGetUniformLocation(P, array_i(s, "step0", i));
            ctx->uni_step1[i] = glGetUniformLocation(P, array_i(s, "step1", i));
            ctx->uni_step2[i] = glGetUniformLocation(P, array_i(s, "step2", i));
            ctx->uni_step3[i] = glGetUniformLocation(P, array_i(s, "step3", i));
            ctx->uni_depth[i] = glGetUniformLocation(P, array_i(s, "depth", i));
        }
        return 1;
    }
    return 0;
}

static void il_fini_uniforms(struct il_context *ctx)
{
    if (ctx->uni_coeff)
        free(ctx->uni_coeff);
}

/*---------------------------------------------------------------------------*/

static int il_init_vertices(struct il_context *ctx)
{
    float v[4][2] = {{ -1.0,  1.0 },
                     { -1.0, -1.0 },
                     {  1.0,  1.0 },
                     {  1.0, -1.0 }};

    /* Initialize a vertex buffer object with the unit square. */

    glGenBuffers(1, &ctx->buffer_vertex);

    glBindBuffer(GL_ARRAY_BUFFER, ctx->buffer_vertex);
    glBufferData(GL_ARRAY_BUFFER, 8 * sizeof (float), v, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    return 1;
}

static void il_fini_vertices(struct il_context *ctx)
{
    glDeleteBuffers(1, &ctx->buffer_vertex);
}

static void il_draw_vertices(const struct il_context *ctx)
{
    glBindBuffer(GL_ARRAY_BUFFER, ctx->buffer_vertex);
    {
#if 1 /* OSX doesn't do glVertexAttribPointer(0) */

        glEnableClientState(GL_VERTEX_ARRAY);
        {
            glVertexPointer(2, GL_FLOAT, 0, NULL);
            glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        }
        glEnableClientState(GL_VERTEX_ARRAY);

#else

        glEnableVertexAttribArray(0);
        {
            glVertexAttribPointer(0, 2, GL_FLOAT, 0, 0, NULL);
            glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        }
        glDisableVertexAttribArray(0);

#endif
    }
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

/*---------------------------------------------------------------------------*/

struct il_context *il_init_context(int n, int w, int h, const char *vert_name,
                                                        const char *frag_name)
{
    struct il_context *ctx;

    /* Allocate, initialize, and return a new interleaver context. */

    if ((ctx = (struct il_context *) calloc(1, sizeof (struct il_context))))
    {
        const char *v = vert_name ? vert_name : IL_DEFAULT_VERT;
        const char *f = frag_name ? frag_name : IL_DEFAULT_FRAG;

        ctx->eyes = n;

        if (il_init_buffers (ctx, w, h) &&
            il_init_shaders (ctx, v, f) &&
            il_init_uniforms(ctx      ) &&
            il_init_vertices(ctx      ))

            return ctx;

        il_fini_context(ctx);
    }

    return NULL;
}

void il_fini_context(struct il_context *ctx)
{
    /* Safely release all resources associated with the given context. */

    if (ctx)
    {
        il_fini_vertices(ctx);
        il_fini_uniforms(ctx);
        il_fini_shaders (ctx);
        il_fini_buffers (ctx);

        free(ctx);
    }
}

/*---------------------------------------------------------------------------*/

struct il_display *il_init_display(int n)
{
    struct il_display *dsp;

    /* Allocate, initialize, and return a new interleaver display. */

    if ((dsp = (struct il_display *) calloc(1, sizeof (struct il_display))))
    {
        if ((dsp->cycle = (float *) calloc(n, sizeof (float))) &&
            (dsp->step0 = (float *) calloc(n, sizeof (float))) &&
            (dsp->step1 = (float *) calloc(n, sizeof (float))) &&
            (dsp->step2 = (float *) calloc(n, sizeof (float))) &&
            (dsp->step3 = (float *) calloc(n, sizeof (float))) &&
            (dsp->depth = (float *) calloc(n, sizeof (float))))
        {
            dsp->debug = 1.0f;
            return dsp;
        }

        il_fini_display(dsp);
    }

    return NULL;
}

void il_fini_display(struct il_display *dsp)
{
    if (dsp)
    {
        if (dsp->depth) free(dsp->depth);
        if (dsp->step3) free(dsp->step3);
        if (dsp->step2) free(dsp->step2);
        if (dsp->step1) free(dsp->step1);
        if (dsp->step0) free(dsp->step0);
        if (dsp->cycle) free(dsp->cycle);

        free(dsp);
    }
}

/*---------------------------------------------------------------------------*/

static void il_basis(const struct il_display *dsp, float *R,
                                                   float *U,
                                                   float *N)
{
    /* Find the basis of the screen space. */

    R[0] = dsp->BR[0] - dsp->BL[0];
    R[1] = dsp->BR[1] - dsp->BL[1];
    R[2] = dsp->BR[2] - dsp->BL[2];

    U[0] = dsp->TL[0] - dsp->BL[0];
    U[1] = dsp->TL[1] - dsp->BL[1];
    U[2] = dsp->TL[2] - dsp->BL[2];

    N[0] = R[1] * U[2] - R[2] * U[1];
    N[1] = R[2] * U[0] - R[0] * U[2];
    N[2] = R[0] * U[1] - R[1] * U[0];

    normalize(R);
    normalize(U);
    normalize(N);
}

static float *il_transform(const struct il_display *dsp, const float *p,
                                                               float *v)
{
    float R[3];
    float U[3];
    float N[3];
    float e[3];
    float w[3];

    float dx, dy;
    float pp, ss;

    float pitch = dsp->pitch / dsp->debug;
    float thick = dsp->thick * dsp->debug;

    float A[16];
    float B[16];
    float C[16];

    float T[16];
    float M[16];

    il_basis(dsp, R, U, N);

    /* Find the vector from the center of the screen to the eye. */

    e[0] = p[0] - (dsp->TL[0] + dsp->BR[0]) * 0.5f;
    e[1] = p[1] - (dsp->TL[1] + dsp->BR[1]) * 0.5f;
    e[2] = p[2] - (dsp->TL[2] + dsp->BR[2]) * 0.5f;

    /* Transform this vector into screen space. */

    w[0] = e[0] * R[0] + e[1] * R[1] + e[2] * R[2];
    w[1] = e[0] * U[0] + e[1] * U[1] + e[2] * U[2];
    w[2] = e[0] * N[0] + e[1] * N[1] + e[2] * N[2];

    /* Compute the pitch and shift reduction due to optical thickness. */

    pp =      pitch * (w[2] - thick) / w[2];
    ss = dsp->shift * (w[2] - thick) / w[2];

    /* Compute the parallax due to optical thickness. */

    dx = thick * w[0] / w[2] - ss;
    dy = thick * w[1] / w[2];

    /* Compose the line screen transformation matrix. */

    scaling    (A, pp, pp, 1.0f);
    zrotation  (B, -dsp->angle);
    translation(C, dx, dy, 0.0f);

    multiply(T, A, B);
    multiply(M, T, C);

    /* We only need to transform X, so return the first row. */

    v[0] = M[ 0];
    v[1] = M[ 4];
    v[2] = M[ 8];
    v[3] = M[12];

    return v;
}

/*---------------------------------------------------------------------------*/

void il_prep(const struct il_context *ctx,
             const struct il_display *dsp, int i)
{
    int x = (int) (dsp->viewport_x * dsp->quality);
    int y = (int) (dsp->viewport_y * dsp->quality);
    int w = (int) (dsp->viewport_w * dsp->quality);
    int h = (int) (dsp->viewport_h * dsp->quality);

    /* Bind the selected eye buffer as render target. */

    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, ctx->buffer_frame[i]);

    /* Scale and shift the rendered area to control quality. */

    glViewport(x, y, w, h);
    glScissor (x, y, w, h);
}

void il_draw(const struct il_context *ctx,
             const struct il_display *dsp, const float *p)
{
    /* Compute the screen size and subpixel offset. */

    const float w = distance(dsp->BL, dsp->BR);
    const float h = distance(dsp->BL, dsp->TL);
    const float d = w / (3 * dsp->viewport_w);

    int i;

    /* Enable the program. */

    glUseProgram(ctx->program);
    {
        /* Set the uniforms. */

        glUniform4f(ctx->uni_size,     w * 0.5f, h * 0.5f, 0.0f, 1.0f);
        glUniform1f(ctx->uni_quality, dsp->quality);
        glUniform3f(ctx->uni_offset,  -d, 0, d);

        for (i = 0; i < ctx->eyes; ++i)
        {
            float c[4];

            il_transform(dsp, p + 3 * i, c);

            glUniform4f(ctx->uni_coeff[i], c[0], c[1], c[2], c[3]);

            glUniform1f(ctx->uni_cycle[i], dsp->cycle[i]);
            glUniform1f(ctx->uni_step0[i], dsp->step0[i]);
            glUniform1f(ctx->uni_step1[i], dsp->step1[i]);
            glUniform1f(ctx->uni_step2[i], dsp->step2[i]);
            glUniform1f(ctx->uni_step3[i], dsp->step3[i]);
            glUniform1f(ctx->uni_depth[i], dsp->depth[i]);
        }

        /* Draw a screen-filling quad. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);

        glViewport(dsp->viewport_x, dsp->viewport_y,
                   dsp->viewport_w, dsp->viewport_h);
        glScissor (dsp->viewport_x, dsp->viewport_y,
                   dsp->viewport_w, dsp->viewport_h);

        il_bind_buffers (ctx);
        il_draw_vertices(ctx);
        il_free_buffers (ctx);
    }
    glUseProgram(0);
}

/*---------------------------------------------------------------------------*/

void il_perspective(const struct il_display *dsp,
                    const float *p, float n, float f, float *M)
{
    float R[3];
    float U[3];
    float N[3];
    float k;

    float P[16];
    float O[16];
    float T[16];
    float A[16];

    il_basis(dsp, R, U, N);

    k = N[0] * (dsp->BL[0] - p[0]) + 
        N[1] * (dsp->BL[1] - p[1]) +
        N[2] * (dsp->BL[2] - p[2]);

    /* Compute the world-space edges of the view port. */

    double l = n * (R[0] * (p[0] - dsp->BL[0]) +
                    R[1] * (p[1] - dsp->BL[1]) +
                    R[2] * (p[2] - dsp->BL[2])) / k;
    double r = n * (R[0] * (p[0] - dsp->BR[0]) +
                    R[1] * (p[1] - dsp->BR[1]) +
                    R[2] * (p[2] - dsp->BR[2])) / k;
    double b = n * (U[0] * (p[0] - dsp->BL[0]) +
                    U[1] * (p[1] - dsp->BL[1]) +
                    U[2] * (p[2] - dsp->BL[2])) / k;
    double t = n * (U[0] * (p[0] - dsp->TL[0]) +
                    U[1] * (p[1] - dsp->TL[1]) +
                    U[2] * (p[2] - dsp->TL[2])) / k;

    /* Compute the projection. */

    perspective(P, l, r, b, t, n, f);

    /* Account for the orientation of the display. */

    O[0] = R[0]; O[4] = R[1]; O[ 8] = R[2]; O[12] = 0.0f;
    O[1] = U[0]; O[5] = U[1]; O[ 9] = U[2]; O[13] = 0.0f;
    O[2] = N[0]; O[6] = N[1]; O[10] = N[2]; O[14] = 0.0f;
    O[3] = 0.0f; O[7] = 0.0f; O[11] = 0.0f; O[15] = 1.0f;

    /* Move the apex of the frustum to the origin. */

    translation(T, -p[0], -p[1], -p[2]);

    multiply(A, P, O);
    multiply(M, A, T);
}

float il_viewpoints(const struct il_display *dsp,
                    float px, float pd, float *p, int n)
{
    int i;

    /* Compute the channel distance. */

    const float cd =
        px * dsp->debug * distance(dsp->BL, dsp->BR) / dsp->viewport_w;

    /* Compute the view distance. */

    const float vd =
        pd * dsp->thick / cd;

    /* Compute a screen-space basis and origin. */

    float R[3];
    float U[3];
    float N[3];
    float O[3];

    il_basis(dsp, R, U, N);

    O[0] = 0.5f * (dsp->TL[0] + dsp->BR[0]);
    O[1] = 0.5f * (dsp->TL[1] + dsp->BR[1]);
    O[2] = 0.5f * (dsp->TL[2] + dsp->BR[2]);

    /* Compute the eye positions in world space. */

    for (i = 0; i < n; ++i)
    {
        float x = (i - 0.5f * (n - 1.0f)) * pd * dsp->debug;

        p[i * 3 + 0] = O[0] + R[0] * x + N[0] * vd;
        p[i * 3 + 1] = O[1] + R[1] * x + N[1] * vd;
        p[i * 3 + 2] = O[2] + R[2] * x + N[2] * vd;
    }

    return vd;
}

/*---------------------------------------------------------------------------*/
