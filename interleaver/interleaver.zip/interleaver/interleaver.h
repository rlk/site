/*    Copyright (C) 2008 Robert Kooima                                       */
/*                                                                           */
/*    Interleaver is free software; you can redistribute it and/or modify    */
/*    it  under the terms  of the  GNU Lesser  General Public  License as    */
/*    published by the Free Software  Foundation; either version 2 of the    */
/*    License, or (at your option) any later version                         */
/*                                                                           */
/*    This program is distributed in the hope that it will be useful, but    */
/*    WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of    */
/*    MERCHANTABILITY or  FITNESS FOR A PARTICULAR PURPOSE.   See the GNU    */
/*    Lesser General Public License for more details.                        */

#ifndef INTERLEAVER_H
#define INTERLEAVER_H

/*---------------------------------------------------------------------------*/

#define IL_DEFAULT_VERT "interleaver.vert"
#define IL_DEFAULT_FRAG "interleaver.frag"

struct il_context;

struct il_display
{
    /* Window area (in pixels) of this display. */

    int viewport_x;
    int viewport_y;
    int viewport_w;
    int viewport_h;

    /* Off-screen buffer downsampling factor and debug scaling factor. */

    float quality;
    float debug;

    /* Real-world positions of the display corners */

    float BL[3];    /* Bottom-left  */
    float BR[3];    /* Bottom-right */
    float TL[3];    /* Top-left     */

    /* Line screen parameters */

    float pitch;
    float angle;
    float thick;
    float shift;

    float *cycle;
    float *step0;
    float *step1;
    float *step2;
    float *step3;
    float *depth;
};

/*---------------------------------------------------------------------------*/

struct il_context *il_init_context(int, int, int, const char *, const char *);
void               il_fini_context(struct il_context *);

struct il_display *il_init_display(int);
void               il_fini_display(struct il_display *);

/*---------------------------------------------------------------------------*/

void  il_prep(const struct il_context *,
              const struct il_display *, int);
void  il_draw(const struct il_context *,
              const struct il_display *, const float *);

void  il_perspective(const struct il_display *,
                     const float *, float, float, float *);

float il_viewpoints(const struct il_display *, float, float, float *, int);

/*---------------------------------------------------------------------------*/

#endif
