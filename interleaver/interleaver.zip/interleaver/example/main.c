#include <SDL.h>
#include <GL/glew.h>

#include "../interleaver.h"
#include "obj.h"

#define DEFAULT_OBJ "teapot.obj"
#define CONFIG_DAT  "config.dat"

/*---------------------------------------------------------------------------*/
/* Display configuration                                                     */

static int   window_m = SDL_NOFRAME;
static int   window_w = 2560;
static int   window_h = 1600;
static float screen_w = 2.1042f;  /* ft */
static float screen_h = 1.3177f;  /* ft */

static float ppc = 1.250f;  /* Pixels per channel      */
static float ipd = 0.208f;  /* Interpupillary distance */

static struct il_context *context;
static struct il_display *display;

/*---------------------------------------------------------------------------*/
/* Scene configuration                                                       */

static int   eyes             =  4;
static int   model            = -1;
static int   test             =  0;
static int   curr             = -1;

static float model_x_rot      =    0.0f;
static float model_y_rot      =    0.0f;
static float model_scale      =    1.0f;
static float model_grow       =    0.1f;
static float model_offset[3]  =  { 0.0f, 0.0f, 0.0f };

static float eye_position[32];
static float view_distance;

/*---------------------------------------------------------------------------*/

static float calc_ppc(void)
{
    return window_w / screen_w / display->pitch / eyes / display->debug;
}

/*---------------------------------------------------------------------------*/

void read_app_conf(const char *filename)
{
    /* Parse the application options from the named config file. */

    FILE *fp;

    if ((fp = fopen(filename, "r")))
    {
        char  s[256];
        char  k[256];
        char *v;
        int   n;

        while (fgets(s, 256, fp))
        {
            sscanf(s, "%s%n", k, &n);
            v = s + n;

            if      (!strcmp(k, "eyes")) sscanf(v, "%d", &eyes);
            else if (!strcmp(k, "ipd"))  sscanf(v, "%f", &ipd);

            else if (!strcmp(k, "window_m")) sscanf(v, "%d", &window_m);
            else if (!strcmp(k, "window_w")) sscanf(v, "%d", &window_w);
            else if (!strcmp(k, "window_h")) sscanf(v, "%d", &window_h);
            else if (!strcmp(k, "screen_w")) sscanf(v, "%f", &screen_w);
            else if (!strcmp(k, "screen_h")) sscanf(v, "%f", &screen_h);
        }
        fclose(fp);
    }
}

void read_dsp_conf(const char *filename, struct il_display *D)
{
    /* Parse the display options from the named config file. */

    FILE *fp;

    if ((fp = fopen(filename, "r")))
    {
        char  s[256];
        char  k[256];
        char *v;
        int   i;
        int   n;
        float f;

        while (fgets(s, 256, fp))
        {
            sscanf(s, "%s%n", k, &n);
            v = s + n;

            if      (!strcmp(k, "pitch")) sscanf(v, "%f", &D->pitch);
            else if (!strcmp(k, "angle")) sscanf(v, "%f", &D->angle);
            else if (!strcmp(k, "thick")) sscanf(v, "%f", &D->thick);
            else if (!strcmp(k, "shift")) sscanf(v, "%f", &D->shift);

            else if (!strcmp(k, "cycle"))
            {
                sscanf(v, "%d %f", &i, &f);
                D->cycle[i] = f;
            }
            else if (!strcmp(k, "step0"))
            {
                sscanf(v, "%d %f", &i, &f);
                D->step0[i] = f;
            }
            else if (!strcmp(k, "step1"))
            {
                sscanf(v, "%d %f", &i, &f);
                D->step1[i] = f;
            }
            else if (!strcmp(k, "step2"))
            {
                sscanf(v, "%d %f", &i, &f);
                D->step2[i] = f;
            }
            else if (!strcmp(k, "step3"))
            {
                sscanf(v, "%d %f", &i, &f);
                D->step3[i] = f;
            }
            else if (!strcmp(k, "depth"))
            {
                sscanf(v, "%d %f", &i, &f);
                D->depth[i] = f;
            }
        }
        fclose(fp);
    }
}

void write_conf(const char *filename, struct il_display *D)
{
    /* Write all options to the named config file. */

    FILE *fp;

    if ((fp = fopen(filename, "w")))
    {
        int i;

        fprintf(fp, "eyes %d\n", eyes);
        fprintf(fp, "ipd %f\n", ipd);

        fprintf(fp, "window_m %d\n", window_m);
        fprintf(fp, "window_w %d\n", window_w);
        fprintf(fp, "window_h %d\n", window_h);
        fprintf(fp, "screen_w %f\n", screen_w);
        fprintf(fp, "screen_h %f\n", screen_h);

        fprintf(fp, "pitch %f\n", D->pitch);
        fprintf(fp, "angle %f\n", D->angle);
        fprintf(fp, "thick %f\n", D->thick);
        fprintf(fp, "shift %f\n", D->shift);

        for (i = 0; i < eyes; ++i)
        {
            fprintf(fp, "cycle %d %f\n", i, D->cycle[i]);
            fprintf(fp, "step0 %d %f\n", i, D->step0[i]);
            fprintf(fp, "step1 %d %f\n", i, D->step1[i]);
            fprintf(fp, "step2 %d %f\n", i, D->step2[i]);
            fprintf(fp, "step3 %d %f\n", i, D->step3[i]);
            fprintf(fp, "depth %d %f\n", i, D->depth[i]);
        }

        fclose(fp);
    }
}

/*---------------------------------------------------------------------------*/

static void draw_background(float r0, float g0, float b0,
                            float r1, float g1, float b1)
{
    /* Draw a screen-filling rectangle with the given color. */

    glBegin(GL_TRIANGLE_STRIP);
    {
        glColor3f(r0, g0, b0);
        glVertex3fv(display->BL);
        glVertex3fv(display->BR);

        glColor3f(r1, g1, b1);
        glVertex3fv(display->TL);
        glVertex3f(display->BR[0] + display->TL[0] - display->BL[0],
                   display->BR[1] + display->TL[1] - display->BL[1],
                   display->BR[2] + display->TL[2] - display->BL[2]);
    }
    glEnd();
}

static void draw_color(int i)
{
    const float c[8][4] = {
        { 1.0f, 0.0f, 0.0f, 0.0f },
        { 1.0f, 0.5f, 0.0f, 0.0f },
        { 1.0f, 1.0f, 0.0f, 0.0f },
        { 0.0f, 1.0f, 0.0f, 0.0f },
        { 0.0f, 1.0f, 1.0f, 0.0f },
        { 0.0f, 0.0f, 1.0f, 0.0f },
        { 0.5f, 0.0f, 1.0f, 0.0f },
        { 1.0f, 0.0f, 1.0f, 0.0f },
    };

    glClearColor(c[i][0], c[i][1], c[i][2], c[i][3]);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
}

static void draw_scene(const float *p)
{
    GLfloat C0[4] = {  1.0f,  1.0f,  1.0f,  1.0f };
    GLfloat C1[4] = {  1.0f,  1.0f,  0.0f,  1.0f };
    GLfloat P0[4] = {  1.0f,  1.0f,  1.0f,  0.0f };
    GLfloat P1[4] = { -1.0f, -1.0f, -1.0f,  0.0f };

    /* Apply the projection. */

    GLfloat M[16];

    il_perspective(display, p, 0.1f, 2.0f * view_distance, M);

    glMatrixMode(GL_PROJECTION);
    glLoadMatrixf(M);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    /* Draw the background */

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glDisable(GL_LIGHTING);
    glDepthMask(GL_FALSE);

    draw_background(0.0f, 0.2f, 0.5f, 0.0f, 0.8f, 1.0f);

    glDepthMask(GL_TRUE);

    /* Apply the scene GL state. */

    glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  C0);
    glLightfv(GL_LIGHT1, GL_DIFFUSE,  C1);
    glLightfv(GL_LIGHT0, GL_POSITION, P0);
    glLightfv(GL_LIGHT1, GL_POSITION, P1);

    /* Apply the current transformation. */

    glRotatef(model_x_rot, 1.0f, 0.0f, 0.0f);
    glRotatef(model_y_rot, 0.0f, 1.0f, 0.0f);

    glScalef(model_scale,
             model_scale,
             model_scale);

    glTranslatef(model_offset[0],
                 model_offset[1],
                 model_offset[2]);

    /* Draw the model. */

    obj_draw_file(model);
}

/*---------------------------------------------------------------------------*/

static void tweak(float *v, int n,
                  float  d, int i)
{
    if (i == -1)
        for (i = 0; i < n; ++i)
            v[i] += d;
    else
        v[i] += d;
}

static void print_list(const char *name, const float *v, int n)
{
    int i;

    printf("%s ", name);

    for (i = 0; i < eyes; ++i)
        printf("%7.5f ", v[i]);

    printf("\n");
}

/*---------------------------------------------------------------------------*/

static int do_start(const char *name)
{
    float bound[6];
    float range[3];
    float max = 0.0f;

    /* Initialize the interleaver context. */

    if ((display = il_init_display(eyes)) &&
        (context = il_init_context(eyes, window_w, window_h,
                                   "../interleaver.vert",
                                   "../interleaver.frag")))
    {
        read_dsp_conf(CONFIG_DAT, display);

        ppc = calc_ppc();

        /* Initialize the display structure. */

        display->viewport_x = 0;
        display->viewport_y = 0;
        display->viewport_w = window_w;
        display->viewport_h = window_h;

        display->quality = 1.0f;

        display->BL[0] = -0.5f * screen_w;
        display->BL[1] = -0.5f * screen_h;
        display->BL[2] =  0.0f;

        display->BR[0] =  0.5f * screen_w;
        display->BR[1] = -0.5f * screen_h;
        display->BR[2] =  0.0f;

        display->TL[0] = -0.5f * screen_w;
        display->TL[1] =  0.5f * screen_h;
        display->TL[2] =  0.0f;

        /* Initialize the eye positions. */

        view_distance
            = il_viewpoints(display, ppc, ipd, eye_position, eyes);

        printf("Viewing distance is %.1f ft.\n", view_distance);

        /* Load the model. */

        model = obj_add_file(name);

        /* Find a model offset and scale to fit the display. */

        obj_get_file_box(model, bound);

        model_offset[0] = -0.5f * (bound[3] + bound[0]);
        model_offset[1] = -0.5f * (bound[4] + bound[1]);
        model_offset[2] = -0.5f * (bound[5] + bound[2]);

        range[0] = bound[3] - bound[0];
        range[1] = bound[4] - bound[1];
        range[2] = bound[5] - bound[2];

        max = range[0];

        if (range[1] > range[0] && range[1] > range[2]) max = range[1];
        if (range[2] > range[0] && range[2] > range[1]) max = range[2];

        if (max > 0.0)
            model_scale = 0.5f * screen_w / max;
        else
            model_scale = 1.0f;

        model_grow = 0.1f * model_scale;

        return 1;
    }
    return 0;
}

static void do_close(void)
{
    if (display) il_fini_display(display);
    if (context) il_fini_context(context);
}

static void do_paint(void)
{
    int i;

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /* Render all views to off-screen buffers. */

    for (i = 0; i < eyes; ++i)
    {
        il_prep(context, display, i);

        if (test)
            draw_color(i);
        else
            draw_scene(eye_position + i * 3);
    }

    /* Interleave all views to the screen. */

    glDepthMask(GL_FALSE);
    il_draw(context, display, eye_position);
    glDepthMask(GL_TRUE);
}

static void do_point(int x, int y)
{
    if (SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(1))
    {
        model_x_rot += (float) y * 360.0f / window_w;
        model_y_rot += (float) x * 360.0f / window_w;
    }
}

static void do_click(int x, int y, int b, int s)
{
    if (b == 4 && s == 1) model_scale -= model_grow;
    if (b == 5 && s == 1) model_scale += model_grow;
}

static int do_key(int c, int d)
{
    if (d)
    {
        /* Unmodified keys. */

        switch (c)
        {
        case SDLK_a: tweak(display->cycle, eyes, +0.01, curr); break;
        case SDLK_z: tweak(display->cycle, eyes, -0.01, curr); break;
        case SDLK_s: tweak(display->step0, eyes, +0.01, curr); break;
        case SDLK_x: tweak(display->step0, eyes, -0.01, curr); break;
        case SDLK_d: tweak(display->step1, eyes, +0.01, curr); break;
        case SDLK_c: tweak(display->step1, eyes, -0.01, curr); break;
        case SDLK_f: tweak(display->step2, eyes, +0.01, curr); break;
        case SDLK_v: tweak(display->step2, eyes, -0.01, curr); break;
        case SDLK_g: tweak(display->step3, eyes, +0.01, curr); break;
        case SDLK_b: tweak(display->step3, eyes, -0.01, curr); break;
        case SDLK_h: tweak(display->depth, eyes, +0.01, curr); break;
        case SDLK_n: tweak(display->depth, eyes, -0.01, curr); break;
        case SDLK_w: display->debug = (display->debug > 1.0) ? 1.0 : 50.0; break;
        case SDLK_0:
        case SDLK_1:
        case SDLK_2:
        case SDLK_3:
        case SDLK_4:
        case SDLK_5:
        case SDLK_6:
        case SDLK_7:
        case SDLK_8:
        case SDLK_9:         curr = c - SDLK_0;      break;
        case SDLK_BACKQUOTE: curr =         -1;      break;
        case SDLK_TAB:       test = 1 - test;        break;
        case SDLK_RETURN: write_conf(CONFIG_DAT, display); break;
        case SDLK_ESCAPE:                            return 0;
        }

        if (SDL_GetModState() & KMOD_SHIFT)
            
            switch (c) /* Shifted keys. */
            {
            case SDLK_LEFT:  display->angle -= 0.005f; break;
            case SDLK_RIGHT: display->angle += 0.005f; break;
            case SDLK_DOWN:  display->pitch -= 0.010f;  break;
            case SDLK_UP:    display->pitch += 0.010f;  break;
            }

        else
            
            switch (c) /* Unshifted keys. */
            {
            case SDLK_LEFT:  display->shift -= 0.00005f; break;
            case SDLK_RIGHT: display->shift += 0.00005f; break;
            case SDLK_DOWN:  display->thick -= 0.00010f; break;
            case SDLK_UP:    display->thick += 0.00010f; break;
            }

        ppc = calc_ppc();
        view_distance = il_viewpoints(display, ppc, ipd, eye_position, eyes);

        printf("ppc   %9.5f\n", ppc);
        printf("pitch %9.5f\n", display->pitch);
        printf("angle %9.5f\n", display->angle);
        printf("thick %9.5f\n", display->thick);
        printf("shift %9.5f\n", display->shift);

        print_list("cycle", display->cycle, eyes);
        print_list("step0", display->step0, eyes);
        print_list("step1", display->step1, eyes);
        print_list("step2", display->step2, eyes);
        print_list("step3", display->step3, eyes);
        print_list("depth", display->depth, eyes);

        printf("\n");
    }

    return 1;
}

/*---------------------------------------------------------------------------*/

static int do_event(SDL_Event *e)
{
    static int x = 0;
    static int y = 0;

    switch (e->type)
    {
    case SDL_MOUSEMOTION:
        do_point(e->motion.x - x, e->motion.y - y);
        x = e->motion.x;
        y = e->motion.y;
        return 1;

    case SDL_MOUSEBUTTONDOWN:
        do_click(x, y, e->button.button, 1);
        break;

    case SDL_MOUSEBUTTONUP:
        do_click(x, y, e->button.button, 0);
        break;

    case SDL_KEYDOWN:
        return do_key(e->key.keysym.sym, 1);

    case SDL_KEYUP:
        return do_key(e->key.keysym.sym, 0);

    case SDL_QUIT:
        return 0;
    }

    return 1;
}

int main(int argc, char *argv[])
{
    read_app_conf(CONFIG_DAT);

    /* Initialize SDL and create an OpenGL window. */

    if (SDL_Init(SDL_INIT_VIDEO) == 0)
    {
        SDL_GL_SetAttribute(SDL_GL_RED_SIZE,     5);
        SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE,   5);
        SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE,    5);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,  16);
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

        if (SDL_SetVideoMode(window_w, window_h, 0,
                             window_m * SDL_FULLSCREEN | SDL_OPENGL))
        {
            glewInit();

            /* Start the application. */

            if (do_start((argc > 1) ? argv[1] : DEFAULT_OBJ))
            {
                int run = 1;

                /* Run the main loop. */

                while (run)
                {
                    SDL_Event e;

                    /* Process all pending events. */

                    if    (SDL_WaitEvent(&e)) run &= do_event(&e);
                    while (SDL_PollEvent(&e)) run &= do_event(&e);

                    /* Render the scene. */

                    do_paint();

                    SDL_GL_SwapBuffers();
                }

                do_close();
            }
        }
        else fprintf(stderr, "SDL_SetVideoMode: %s\n", SDL_GetError());

        SDL_Quit();
    }
    else fprintf(stderr, "SDL_Init: %s\n", SDL_GetError());

    return 0;
}

/*---------------------------------------------------------------------------*/
