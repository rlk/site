#ifndef MAIN_H
#define MAIN_H

/* This module expects the following functions to be defined externally:     */
/*                                                                           */
/*     void init_lua(void)    Initialize Lua state                           */
/*     void init_ogl(void)    Initialize OpenGL state                        */
/*     void draw_ogl(void)    Render the OpenGL scene                        */
/*     void free_ogl(void)    Finalize Opengl state                          */

/*---------------------------------------------------------------------------*/

#define DRAW_LAND     1
#define DRAW_SKY      2
#define DRAW_GRASS    4
#define DRAW_OBJECTS  8
#define DRAW_WATER   16
#define DRAW_SHADERS 32

/*---------------------------------------------------------------------------*/

#ifdef __linux__
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glx.h>
#include <GL/glext.h>
#define glGetProcAddress(n) glXGetProcAddressARB((GLubyte *) n)
#endif

#ifdef _WIN32
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include "glext.h"
#define glGetProcAddress(n) wglGetProcAddress(n)
#endif

#ifdef __APPLE__
#define GL_GLEXT_LEGACY 1
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#define GL_GLEXT_PROTOTYPES 1
#include "glext.h"
#endif

/*---------------------------------------------------------------------------*/

#ifndef __APPLE__
extern PFNGLGETOBJECTPARAMETERIVARBPROC     glGetObjectParameterivARB;
extern PFNGLGETUNIFORMLOCATIONARBPROC       glGetUniformLocationARB;
extern PFNGLBINDATTRIBLOCATIONARBPROC       glBindAttribLocationARB;
extern PFNGLUSEPROGRAMOBJECTARBPROC         glUseProgramObjectARB;
extern PFNGLVALIDATEPROGRAMARBPROC          glValidateProgramARB;
extern PFNGLCREATESHADEROBJECTARBPROC       glCreateShaderObjectARB;
extern PFNGLCREATEPROGRAMOBJECTARBPROC      glCreateProgramObjectARB;
extern PFNGLSHADERSOURCEARBPROC             glShaderSourceARB;
extern PFNGLCOMPILESHADERARBPROC            glCompileShaderARB;
extern PFNGLATTACHOBJECTARBPROC             glAttachObjectARB;
extern PFNGLLINKPROGRAMARBPROC              glLinkProgramARB;
extern PFNGLGETINFOLOGARBPROC               glGetInfoLogARB;
extern PFNGLDELETEOBJECTARBPROC             glDeleteObjectARB;
extern PFNGLUNIFORM1IARBPROC                glUniform1iARB;
extern PFNGLUNIFORM1FARBPROC                glUniform1fARB;
extern PFNGLUNIFORM2FARBPROC                glUniform2fARB;
extern PFNGLUNIFORM3FARBPROC                glUniform3fARB;
extern PFNGLUNIFORM4FARBPROC                glUniform4fARB;
extern PFNGLUNIFORMMATRIX3FVARBPROC         glUniformMatrix3fvARB;
extern PFNGLGENFRAMEBUFFERSEXTPROC          glGenFramebuffersEXT;
extern PFNGLGENRENDERBUFFERSEXTPROC         glGenRenderbuffersEXT;
extern PFNGLDELETEFRAMEBUFFERSEXTPROC       glDeleteFramebuffersEXT;
extern PFNGLDELETERENDERBUFFERSEXTPROC      glDeleteRenderbuffersEXT;
extern PFNGLBINDFRAMEBUFFEREXTPROC          glBindFramebufferEXT;
extern PFNGLBINDRENDERBUFFEREXTPROC         glBindRenderbufferEXT;
extern PFNGLFRAMEBUFFERTEXTURE2DEXTPROC     glFramebufferTexture2DEXT;
extern PFNGLFRAMEBUFFERRENDERBUFFEREXTPROC  glFramebufferRenderbufferEXT;
extern PFNGLRENDERBUFFERSTORAGEEXTPROC      glRenderbufferStorageEXT;
extern PFNGLENABLEVERTEXATTRIBARRAYARBPROC  glEnableVertexAttribArrayARB;
extern PFNGLDISABLEVERTEXATTRIBARRAYARBPROC glDisableVertexAttribArrayARB;
extern PFNGLVERTEXATTRIBPOINTERARBPROC      glVertexAttribPointerARB;
extern PFNGLGENBUFFERSARBPROC               glGenBuffersARB;
extern PFNGLBINDBUFFERARBPROC               glBindBufferARB;
extern PFNGLMAPBUFFERARBPROC                glMapBufferARB;
extern PFNGLUNMAPBUFFERARBPROC              glUnmapBufferARB;
extern PFNGLBUFFERDATAARBPROC               glBufferDataARB;
extern PFNGLDELETEBUFFERSARBPROC            glDeleteBuffersARB;
extern PFNGLACTIVETEXTUREARBPROC            glActiveTextureARB;
extern PFNGLTEXIMAGE3DEXTPROC               glTexImage3DEXT;
#endif

extern GLboolean GL_has_ARB_shader_objects;
extern GLboolean GL_has_ARB_fragment_shader;
extern GLboolean GL_has_ARB_vertex_shader;
extern GLboolean GL_has_ARB_vertex_buffer_object;
extern GLboolean GL_has_EXT_framebuffer_object;

/*---------------------------------------------------------------------------*/

#ifndef MAX
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif

#define CLAMP(x, a, z) MIN(MAX(x, a), z)

void check_err(const char *);
void check_log(GLhandleARB);
void validate (GLhandleARB);

GLhandleARB make_program(const char *, const char *);

float get_val_f(const char *);
int   get_val_i(const char *);
int   get_val_b(const char *);

void  set_val_f(const char *, float);
void  set_val_i(const char *, int);
void  set_val_b(const char *, int);

float get_time(void);

/*---------------------------------------------------------------------------*/

#endif
