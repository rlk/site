#ifndef WATER_H
#define WATER_H

#include "main.h"

/*---------------------------------------------------------------------------*/

GLuint water_n_map;

void init_water(void);
void step_water(float);
void draw_water(float, GLuint, GLuint);
void free_water(void);

/*---------------------------------------------------------------------------*/

#endif
