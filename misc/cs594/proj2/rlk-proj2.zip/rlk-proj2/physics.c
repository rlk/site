#include <ode/ode.h>

#include "terrain.h"
#include "physics.h"
#include "main.h"
#include "obj.h"

/*---------------------------------------------------------------------------*/
/* The physical world.                                                       */

#define MAX_CONTACTS 24

static dWorldID       world;
static dSpaceID       space;
static dJointGroupID  group;
static dGeomID        water;
static dGeomID        point;
static dGeomID        sphere;
static dBodyID        camera;
static dGeomID        trimesh;
static dTriMeshDataID tridata;

static dGeomID        grabbed;
static dGeomID        picked;
static dReal          depth;

/*---------------------------------------------------------------------------*/
/* The terrain physics trimesh.                                              */

struct vert
{
    dVector3 v;
};

struct face
{
    int i[3];
};

static struct vert *vert;
static struct face *face;

/*---------------------------------------------------------------------------*/
/* This object cache stores one copy of each loaded object.  ODE geoms look  */
/* here to know how to be drawn.                                             */

struct object
{
    char *name;
    int   data;
    float w;
    float h;
    float d;
    float m;
    int   index;
    int   class;
};

static struct object object[MAX_OBJECTS] = {
    { "data/stove.obj",       0, 0, 0, 0,  2.00f, 0, dBoxClass    },
    { "data/couch.obj",       0, 0, 0, 0,  1.00f, 1, dBoxClass    },
    { "data/soccor_ball.obj", 0, 0, 0, 0,  0.05f, 2, dSphereClass },
    { "data/takeout.obj",     0, 0, 0, 0,  0.05f, 3, dBoxClass    },
    { "data/wood_block.obj",  0, 0, 0, 0,  0.50f, 4, dBoxClass    },
    { "data/wood_panel.obj",  0, 0, 0, 0,  0.50f, 5, dBoxClass    },
};

static GLuint object_prog;

/*---------------------------------------------------------------------------*/

static void get_point(float p[3], float v[3])
{
    float P = get_val_f("camera_phi")   * 0.01745329f;
    float T = get_val_f("camera_theta") * 0.01745329f;

    v[0] = -(float) (sin(T) * cos(P));
    v[1] =  (float) (         sin(P));
    v[2] = -(float) (cos(T) * cos(P));

    p[0] = get_val_f("camera_x");
    p[1] = get_val_f("camera_y");
    p[2] = get_val_f("camera_z");
}

/*---------------------------------------------------------------------------*/

static void callback(void *data, dGeomID o1, dGeomID o2)
{
    dBodyID b1 = dGeomGetBody(o1);
    dBodyID b2 = dGeomGetBody(o2);

    if (b1 && b2 && dAreConnectedExcluding(b1, b2, dJointTypeContact))
        return;

    /* Two geoms associated with the same body do not collide. */

    if (b1 == 0 || b2 == 0 || b1 != b2)
    {
        dContact contact[MAX_CONTACTS];
        int sz = sizeof (dContact);

        int i;
        int n;

        /* Find and enumerate all collision points. */

        if ((n = dCollide(o1, o2, MAX_CONTACTS, &contact[0].geom, sz)))
        {
            /* Create a contact joint for each collision, if requsted. */

            for (i = 0; i < n; ++i)
            {
                if (o1 == point || o2 == point)
                {
                    if (o1 != water && o2 != water)
                    {
                        if (contact[i].geom.depth < depth)
                        {
                            picked = o1;
                            depth  = contact[i].geom.depth;
                        }
                    }
                }
                else
                {
                    dJointID c;

                    contact[i].surface.mode = dContactBounce
                                            | dContactSoftCFM
                                            | dContactSoftERP;

                    if ((o1 == water || o2 == water))
                    {
                        if (o2 == sphere || o1 == sphere)
                            continue;

                        contact[i].surface.mu         = 100.00f;
                        contact[i].surface.bounce     =   0.00f;
                        contact[i].surface.soft_cfm   =   0.90f;
                        contact[i].surface.soft_erp   =   0.05f;
                        contact[i].surface.bounce_vel =   0.10f;
                    }
                    else
                    {
                        contact[i].surface.mu         = 100.00f;
                        contact[i].surface.bounce     =   0.50f;
                        contact[i].surface.soft_cfm   =   0.01f;
                        contact[i].surface.soft_erp   =   0.20f;
                        contact[i].surface.bounce_vel =   0.10f;
                    }

                    c = dJointCreateContact(world, group, contact + i);
                
                    dJointAttach(c, b1, b2);
                }
            }
        }
    }
}

/*---------------------------------------------------------------------------*/

void init_physics(void)
{
    float n = get_val_f("camera_near");

    int w = get_terrain_w();
    int h = get_terrain_h();

    int nv = (w * h);
    int nf = (w - 1) * (h - 1) * 2;

    grabbed = 0;
    picked  = 0;
    depth   = dInfinity;

    /* Initialize the physical world with a water plane. */

    world = dWorldCreate();
    space = dHashSpaceCreate(0);
    group = dJointGroupCreate(0);
    water = dCreatePlane(space, 0.0f, 1.0f, 0.0f, 0.0f);

    /* Initialize a camera body. */

    point  = dCreateRay   (space, 8.0f);
    sphere = dCreateSphere(space, 2.0f * (float) sqrt(n * n + n * n));
    camera = dBodyCreate(world);

    dGeomSetBody(sphere, camera);
    dBodySetGravityMode(camera, 0);

    /* Initalize the terrain trimesh. */

    if ((vert = (struct vert *) calloc(nv, sizeof (struct vert))) &&
        (face = (struct face *) calloc(nf, sizeof (struct face))))
    {
        int i;
        int r;
        int c;

        /* Construct the vertex array. */

        for (r = 0; r < h; ++r)
            for (c = 0; c < w; ++c)
            {
                float v[3];

                get_terrain_v(v, r, c);

                vert[w * r + c].v[0] = (dReal) v[0];
                vert[w * r + c].v[1] = (dReal) v[1];
                vert[w * r + c].v[2] = (dReal) v[2];
            }

        /* Construct the face array. */

        for (i = 0, r = 0; r < h - 1; ++r)
            for (c = 0; c < w - 1; ++c)
            {
                face[i].i[0] = w * (r + 0) + (c + 0);
                face[i].i[1] = w * (r + 1) + (c + 1);
                face[i].i[2] = w * (r + 1) + (c + 0);

                i++;

                face[i].i[0] = w * (r + 0) + (c + 0);
                face[i].i[1] = w * (r + 0) + (c + 1);
                face[i].i[2] = w * (r + 1) + (c + 1);

                i++;
            }

        /* Create the trimesh geom. */

        tridata = dGeomTriMeshDataCreate();

        dGeomTriMeshDataBuildSimple(tridata, vert[0].v, nv,
                                             face[0].i, nf * 3);

        trimesh = dCreateTriMesh(space, tridata, NULL, NULL, NULL);
    }

    /* Set the properties of the physical system. */

    dWorldSetGravity(world, 0, -32, 0);
    dWorldSetAutoDisableFlag(world, 1);

    dGeomSetCategoryBits(water,   0x1);
    dGeomSetCategoryBits(trimesh, 0x1);
    dGeomSetCategoryBits(sphere,  0x4);
    dGeomSetCategoryBits(point,   0x8);

    dGeomSetCollideBits (water,   0x2);
    dGeomSetCollideBits (trimesh, 0x2);
    dGeomSetCollideBits (point,   0x2);
    dGeomSetCollideBits (sphere,  0x3);
}

void step_physics(float dt)
{
    int i, n = dSpaceGetNumGeoms(space);

    dMatrix3 R;
    float p[3];
    float v[3];

    get_point(p, v);

    dBodySetLinearVel (camera, 0, 0, 0);
    dBodySetAngularVel(camera, 0, 0, 0);

    /* Set the position and orientation of the camera. */

    dRFromAxisAndAngle(R, 0.0f, 1.0f, 0.0f,
                        get_val_f("camera_theta") * 0.01745329f);

    dBodySetPosition(camera, p[0], p[1], p[2]);
    dBodySetRotation(camera, R);
    dGeomRaySet     (point,  p[0], p[1], p[2], v[0], v[1], v[2]);

    if (grabbed)
    {
        dBodyID body = dGeomGetBody(grabbed); 

        float r = ((struct object *) dGeomGetData(grabbed))->w / 2.0f + 4.0f;

        dBodySetLinearVel (body, 0, 0, 0);
        dBodySetAngularVel(body, 0, 0, 0);

        dBodySetPosition(body, p[0] + v[0] * r,
                               p[1] + v[1] * r,
                               p[2] + v[2] * r);
        dBodySetRotation(body, R);
    }
    
    /* Detect all collisions and integrate the physical world. */

    picked = 0;
    depth  = dInfinity;

    dSpaceCollide(space, 0, callback);
    dWorldQuickStep(world, dt);
    dJointGroupEmpty(group);

    /* Update the post-collision camera position. */

    set_val_f("camera_x", (float) dBodyGetPosition(camera)[0]);
    set_val_f("camera_y", (float) dBodyGetPosition(camera)[1]);
    set_val_f("camera_z", (float) dBodyGetPosition(camera)[2]);

    /* Dampen the velocity of all submerged bodies. */

    for (i = 0; i < n; ++i)
    {
        dGeomID geom = dSpaceGetGeom(space, i);
        dBodyID body = dGeomGetBody(geom);

        if (body && body != camera && dBodyGetPosition(body)[1] < 0.0)
        {
            float lk = 1.0f - 1.00f * dt;
            float ak = 1.0f - 0.10f * dt;

            dBodySetLinearVel(body,
                              dBodyGetLinearVel(body)[0] * lk,
                              dBodyGetLinearVel(body)[1],
                              dBodyGetLinearVel(body)[2] * lk);

            dBodySetAngularVel(body,
                               dBodyGetAngularVel(body)[0] * ak,
                               dBodyGetAngularVel(body)[1] * ak,
                               dBodyGetAngularVel(body)[2] * ak);
        }
    }
}

void free_physics(void)
{
    if (vert) free(vert);
    if (face) free(face);

    /* Delete all physics resources. */

    dGeomTriMeshDataDestroy(tridata);

    dJointGroupEmpty(group);
    dSpaceDestroy(space);
    dWorldDestroy(world);
}

/*---------------------------------------------------------------------------*/

void init_objects(void)
{
    float b[6];
    int   i;

    object_prog = make_program("data/object.vert", "data/object.frag");

    /* Load OBJ files for all objects. */

    for (i = 0; i < MAX_OBJECTS; ++i)
    {
        object[i].data = obj_add_file(object[i].name);

        /* Assume the object is centered on the origin. */

        obj_bound_file(object[i].data, b);

        object[i].w =  MAX(b[3] - b[0], 0.25f);
        object[i].h =  MAX(b[4] - b[1], 0.25f);
        object[i].d =  MAX(b[5] - b[2], 0.25f);
    }
}

void draw_objects(int flags, float clip, GLuint water_map)
{
    int i, n = dSpaceGetNumGeoms(space);

    if (flags & DRAW_SHADERS)
    {
        glUseProgramObjectARB(object_prog);

        glActiveTextureARB(GL_TEXTURE5_ARB);
        glBindTexture(GL_TEXTURE_2D, water_map);
        glActiveTextureARB(GL_TEXTURE0_ARB);

        glUniform1iARB(glGetUniformLocationARB(object_prog, "color_map"), 0);
        glUniform1iARB(glGetUniformLocationARB(object_prog, "water_map"), 5);
        glUniform1fARB(glGetUniformLocationARB(object_prog, "clip"), clip);
        glUniform1fARB(glGetUniformLocationARB(object_prog, "mud_coeff"),
                                                  get_val_f("mud_coeff"));
        glUniform4fARB(glGetUniformLocationARB(object_prog, "mud_color"),
                                                  get_val_f("mud_color_r"),
                                                  get_val_f("mud_color_g"),
                                                  get_val_f("mud_color_b"),
                                                  1.0f);
    }

    /* Iterate over all geoms in the space. */

    for (i = 0; i < n; ++i)
    {
        dGeomID geom = dSpaceGetGeom(space, i);

        if (dGeomGetBody(geom) && dGeomGetBody(geom) != camera)
        {
            struct object *o = (struct object *) dGeomGetData(geom);
            
            const dReal *p = dGeomGetPosition(geom);
            const dReal *r = dGeomGetRotation(geom);

            glPushMatrix();
            {
                float M[16];

                /* Apply the geom transform to the GL state. */

                M[0]  = (float) r[0]; 
                M[1]  = (float) r[4]; 
                M[2]  = (float) r[8];
                M[3]  = (float)    0; 
                M[4]  = (float) r[1]; 
                M[5]  = (float) r[5]; 
                M[6]  = (float) r[9]; 
                M[7]  = (float)    0; 
                M[8]  = (float) r[2];  
                M[9]  = (float) r[6];  
                M[10] = (float) r[10]; 
                M[11] = (float)    0; 
                M[12] = (float)    0;
                M[13] = (float)    0;
                M[14] = (float)    0;
                M[15] = (float)    1;

                glTranslatef((float) p[0], (float) p[1], (float) p[2]);
                glMultMatrixf(M);

                /* Draw the object associated with this geom. */

                obj_draw_file(o->data);
            }
            glPopMatrix();
        }
    }

    if (flags & DRAW_SHADERS)
    {
        glActiveTextureARB(GL_TEXTURE5_ARB);
        glBindTexture(GL_TEXTURE_2D, 0);
        glActiveTextureARB(GL_TEXTURE0_ARB);

        glUseProgramObjectARB(0);
    }
}

void free_objects(void)
{
    int i;

    /* Release all OBJ storage for each object in the object cache. */

    for (i = MAX_OBJECTS - 1; i >= 0; --i)
        obj_del_file(object[i].data);
}

/*---------------------------------------------------------------------------*/

void add_object(int i, float x, float y, float z)
{
    dGeomID geom = 0;
    dMass   mass;

    /* Create a new body and geom using object i. */

    if (0 <= i && i < MAX_OBJECTS)
    {
        float w = object[i].w;
        float h = object[i].h;
        float d = object[i].d;
        float m = object[i].m;

        switch (object[i].class)
        {
        case dSphereClass:
            dMassSetSphereTotal(&mass, m, w / 2.0f);
            geom = dCreateSphere(space, w / 2.0f);
            break;

        case dBoxClass:
            dMassSetBoxTotal(&mass, m, w, h, d);
            geom = dCreateBox(space, w, h, d);
            break;
        }

        if (geom)
        {
            dBodyID body = dBodyCreate(world);

            dBodySetMass    (body, &mass);
            dBodySetPosition(body, x, y, z);

            dGeomSetBody(geom, body);
            dGeomSetData(geom, object + i);

            dGeomSetCategoryBits(geom, 0x2);
            dGeomSetCollideBits (geom, 0xF);
        }
    }
}

void get_object(void)
{
    grabbed = picked;
}

void put_object(float k)
{
    if (grabbed)
    {
        dBodyID body = dGeomGetBody(grabbed);

        float p[3];
        float v[3];

        get_point(p, v);

        dBodyEnable(body);
        dBodySetLinearVel(body, v[0] * k, v[1] * k, v[2] * k);

        grabbed = 0;
    }
}

/*---------------------------------------------------------------------------*/

static void draw_object_bound(float w, float h, float d,
                              float x, float y, float z)
{
    const float xd = w / 2.0f;
    const float yd = h / 2.0f;
    const float zd = d / 2.0f;

    glColor3f(y * y, y * y, y * y);

    glBegin(GL_QUADS);
    {
        glVertex3f(+xd, -yd, +zd);
        glVertex3f(+xd, -yd, -zd);
        glVertex3f(+xd, +yd, -zd);
        glVertex3f(+xd, +yd, +zd);

        glVertex3f(-xd, -yd, -zd);
        glVertex3f(-xd, -yd, +zd);
        glVertex3f(-xd, +yd, +zd);
        glVertex3f(-xd, +yd, -zd);

        glVertex3f(-xd, +yd, +zd);
        glVertex3f(+xd, +yd, +zd);
        glVertex3f(+xd, +yd, -zd);
        glVertex3f(-xd, +yd, -zd);

        glVertex3f(-xd, -yd, -zd);
        glVertex3f(+xd, -yd, -zd);
        glVertex3f(+xd, -yd, +zd);
        glVertex3f(-xd, -yd, +zd);

        glVertex3f(-xd, -yd, +zd);
        glVertex3f(+xd, -yd, +zd);
        glVertex3f(+xd, +yd, +zd);
        glVertex3f(-xd, +yd, +zd);

        glVertex3f(+xd, -yd, -zd);
        glVertex3f(-xd, -yd, -zd);
        glVertex3f(-xd, +yd, -zd);
        glVertex3f(+xd, +yd, -zd);
    }
    glEnd();
}

void draw_objects_velocity(void)
{
    int i, n = dSpaceGetNumGeoms(space);

    /* Iterate over all geoms in the space. */

    for (i = 0; i < n; ++i)
    {
        dGeomID geom = dSpaceGetGeom(space, i);
        dBodyID body = dGeomGetBody(geom);

        if (body && body != camera)
        {
            struct object *o = (struct object *) dGeomGetData(geom);
            
            const dReal *p = dGeomGetPosition(geom);
            const dReal *r = dGeomGetRotation(geom);
            const dReal *v = dBodyGetLinearVel(body);

            glPushMatrix();
            {
                float M[16];

                /* Apply the geom transform to the GL state. */

                M[0]  = (float) r[0]; 
                M[1]  = (float) r[4]; 
                M[2]  = (float) r[8];
                M[3]  = (float)    0; 
                M[4]  = (float) r[1]; 
                M[5]  = (float) r[5]; 
                M[6]  = (float) r[9]; 
                M[7]  = (float)    0; 
                M[8]  = (float) r[2];  
                M[9]  = (float) r[6];  
                M[10] = (float) r[10]; 
                M[11] = (float)    0; 
                M[12] = (float)    0;
                M[13] = (float)    0;
                M[14] = (float)    0;
                M[15] = (float)    1;

                glTranslatef((float) p[0], (float) p[1], (float) p[2]);
                glMultMatrixf(M);

                /* Draw the bounding box of this geom. */

                draw_object_bound(object[o->index].w,
                                  object[o->index].h,
                                  object[o->index].d,
                                  (float) v[0],
                                  (float) v[1],
                                  (float) v[2]);
            }
            glPopMatrix();
        }
    }
}
