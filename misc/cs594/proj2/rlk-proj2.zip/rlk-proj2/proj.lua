draw_help  = true
shifted    = false
fullscreen = false

move_speed = 10
move_x     = 0
move_y     = 0
move_z     = 0

dzoom = 0.03125

resolution = 3
window_size = {
    {  320,  240 },
    {  640,  480 },
    {  800,  600 },
    { 1024,  768 },
    { 1280, 1024 },
    { 1600, 1200 }
}

function do_click(x, y, b, s)
    if s then
        if     b == 4 then
            camera_zoom = camera_zoom + dzoom
        elseif b == 5 and camera_zoom > dzoom then
            camera_zoom = camera_zoom - dzoom
        else
            drag_x = x;
            drag_y = y;
            drag_b = b;
        end
    else
        drag_b = 0;
    end

    if b == 1 then
        if s then
            get_object()
        else
            if shifted then
                put_object(50.0)
            else
                put_object(0.0)
            end
        end
    end
end

function do_point(x, y)
    if drag_b == 3 then
        light_phi   = light_phi   + 360 * y / window_w
        light_theta = light_theta + 360 * x / window_w

        if light_phi   <  -90 then light_phi   = -90 end
        if light_phi   >  -45 then light_phi   = -45 end
        if light_theta < -180 then light_theta = light_theta + 360 end
        if light_theta >  180 then light_theta = light_theta - 360 end
    else
        camera_phi   = camera_phi   - 360 * camera_zoom * y / window_w
        camera_theta = camera_theta - 360 * camera_zoom * x / window_w

        if camera_phi   <  -90 then camera_phi   = -90 end
        if camera_phi   >   90 then camera_phi   =  90 end
        if camera_theta < -180 then camera_theta = camera_theta + 360 end
        if camera_theta >  180 then camera_theta = camera_theta - 360 end
    end
end

function do_timer(dt)

    local mult_speed = 1

    -- Compute a motion vector from the camera orientation.

    local p = camera_phi   * math.pi / 180
    local t = camera_theta * math.pi / 180

    local dx = math.cos(p) * (move_z * math.sin(t) + move_x * math.cos(t))
    local dy = math.sin(p) *  move_z
    local dz = math.cos(p) * (move_z * math.cos(t) - move_x * math.sin(t))

    if shifted then mult_speed = 4 end

    -- Apply the camera motion.

    camera_x = camera_x + move_speed * mult_speed * dt * dx
    camera_y = camera_y - move_speed * mult_speed * dt * dy
    camera_z = camera_z + move_speed * mult_speed * dt * dz

    -- Animate the light source.
    
    if light_move then
        light_theta = light_theta + dt * 10
    end
end

function do_key(k, s)
    local d

    if s then
        d =  1
    else
        d = -1
    end

    -- Shift keys

    if k == 304 or k == 303 then
        shifted = s
    end
    
    -- Dvorak WADS

    if k ==  97 then move_x = move_x - d end -- A
    if k == 101 then move_x = move_x + d end -- E
    if k ==  44 then move_z = move_z - d end -- ,
    if k == 111 then move_z = move_z + d end -- O

    -- Qwerty WADS

    if k == 100 then move_x = move_x + d end -- D
    if k == 119 then move_z = move_z - d end -- W
    if k == 115 then move_z = move_z + d end -- S

    if s then
        if k == 282 then -- F1
            draw_help = not draw_help
        end
        if k == 283 then -- F2
            fullscreen = not fullscreen
            looping  = false
        end

        if k == 284 and resolution < 6 then -- F3
            resolution = resolution + 1
            window_w = window_size[resolution][1]
            window_h = window_size[resolution][2]
            looping  = false
        end

        if k == 285 and resolution > 1 then -- F4
            resolution = resolution - 1
            window_w = window_size[resolution][1]
            window_h = window_size[resolution][2]
            looping  = false
        end

        if k == 49 then add_object(0, 0, 10, 0) end
        if k == 50 then add_object(1, 0, 10, 0) end
        if k == 51 then add_object(2, 0, 10, 0) end
        if k == 52 then add_object(3, 0, 10, 0) end
        if k == 53 then add_object(4, 0, 10, 0) end
        if k == 54 then add_object(5, 0, 10, 0) end

        if k == 280 then -- Page Up
            camera_zoom = camera_zoom - dzoom
        end
        if k == 281 then -- Page Down
            camera_zoom = camera_zoom + dzoom
        end

        if k == 286 then -- F5
            draw_mode = draw_mode + 1
        end
        if k == 287 then -- F6
            draw_mode = draw_mode - 1
        end
        if k == 288 then -- F7
            water_mode = water_mode + 1
        end
        if k == 289 then -- F8
            water_mode = water_mode - 1
        end

        if k == 293 then -- F12
            looping = false
        end
        if k ==  27 then -- Escape
            running = false
        end
        if k ==  13 then -- Return
            camera_x =  0
            camera_y =  3
            camera_z =  8

            camera_theta =   0
            camera_phi   = -10
        end
    end
end
