#include <stdlib.h>
#include <math.h>

#include "terrain.h"
#include "physics.h"
#include "water.h"
#include "sky.h"
#include "main.h"
#include "obj.h"

/*---------------------------------------------------------------------------*/

static GLuint help_map;

static GLuint shadow_fbo;
static GLuint shadow_color;
static GLuint shadow_depth;

static GLuint reflect_fbo;
static GLuint reflect_color;
static GLuint reflect_depth;

static GLuint refract_fbo;
static GLuint refract_color;
static GLuint refract_depth;

/*---------------------------------------------------------------------------*/

void init_lua(void)
{
    float d = (float) sqrt(TERRAIN_W * TERRAIN_W +
                           TERRAIN_H * TERRAIN_H);

    /* On-screen and off-screen buffer sizes. */

    set_val_i("window_w",  800);
    set_val_i("window_h",  600);

    set_val_i("water_w",  256);
    set_val_i("water_h",  256);

    if (get_val_i("optimization") > 0)
    {
        set_val_i("buffer_w",  512);
        set_val_i("buffer_h",  256);
    }
    else
    {
        set_val_i("buffer_w", 1024);
        set_val_i("buffer_h",  512);
    }

    if (get_val_i("optimization") > 1)
    {
        set_val_i("shadow_w", 1024);
        set_val_i("shadow_h", 1024);
    }
    else
    {
        set_val_i("shadow_w", 2048);
        set_val_i("shadow_h", 2048);
    }

    /* Camera and lighting parameters. */

    set_val_f("camera_x",       0.0f);
    set_val_f("camera_y",       3.0f);
    set_val_f("camera_z",       5.0f);
    set_val_f("camera_far",   256.0f);
    set_val_f("camera_near",    1.0f);
    set_val_f("camera_zoom",    0.5f);
    set_val_f("camera_phi",   -30.0f);
    set_val_f("camera_theta",   0.0f);

    set_val_f("light_far",      2.0f * d);
    set_val_f("light_near",     1.0f);
    set_val_f("light_dist",     1.0f * d);
    set_val_f("light_zoom",     0.5f * d);
    set_val_f("light_phi",    -45.0f);
    set_val_f("light_theta",    0.0f);

    /* Scene parameters. */

    set_val_b("wireframe", 0);

    set_val_f("background_r", 0.55f);
    set_val_f("background_g", 0.45f);
    set_val_f("background_b", 0.35f);

    set_val_f("zenith_r", 0.2f);
    set_val_f("zenith_g", 0.2f);
    set_val_f("zenith_b", 0.8f);

    set_val_f("horizon_r", 1.0f);
    set_val_f("horizon_g", 1.0f);
    set_val_f("horizon_b", 1.0f);

    set_val_f("wind_x", 0.5f);
    set_val_f("wind_y", 0.0f);
    set_val_f("wind_z", 0.5f);

    set_val_f("mud_color_r", 0.55f);
    set_val_f("mud_color_g", 0.45f);
    set_val_f("mud_color_b", 0.35f);
    set_val_f("mud_coeff",  0.125f);

    set_val_i("draw_mode",  0);
    set_val_i("water_mode", 0);
}

/*---------------------------------------------------------------------------*/

static void init_scene(void)
{
    init_sky();
    init_water();
    init_terrain();
    init_physics();
    init_objects();
}

static void draw_scene(int flags, float clip)
{
    if (flags & DRAW_LAND)    draw_terrain(flags, clip, water_n_map);
    if (flags & DRAW_OBJECTS) draw_objects(flags, clip, water_n_map);
}

static void free_scene(void)
{
    free_objects();
    free_physics();
    free_terrain();
    free_water();
    free_sky();
}

/*---------------------------------------------------------------------------*/

static void clear(void)
{
    glClearColor(get_val_f("background_r"),
                 get_val_f("background_g"),
                 get_val_f("background_b"), 0.0f);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

static void draw_image(int w, int h, int c)
{
    int W = get_val_i("window_w");
    int H = get_val_i("window_h");

    glUseProgramObjectARB(0);

    glViewport(0, 0, W, H);

    if (c) clear();

    glMatrixMode(GL_PROJECTION);
    {
        glLoadIdentity();
        glOrtho(0.0, 1.0, 0.0, 1.0, 0.0, 1.0);
    }
    glMatrixMode(GL_TEXTURE);
    {
        glLoadIdentity();
    }
    glMatrixMode(GL_MODELVIEW);

    glPushAttrib(GL_ENABLE_BIT);
    {
        glDisable(GL_LIGHTING);
        glEnable(GL_TEXTURE_2D);

        glColor3f(1.0f, 1.0f, 1.0f);

        glBegin(GL_POLYGON);
        {
            glTexCoord2i(0, 0); glVertex2i(0, 0);
            glTexCoord2i(1, 0); glVertex2i(1, 0);
            glTexCoord2i(1, 1); glVertex2i(1, 1);
            glTexCoord2i(0, 1); glVertex2i(0, 1);
        }
        glEnd();
    }
    glPopAttrib();
}

/*---------------------------------------------------------------------------*/

static void mult_camera_S(void)
{
    float M[16] = {
        0.5f, 0.0f, 0.0f, 0.0f,
        0.0f, 0.5f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.5f, 0.0f,
        0.5f, 0.5f, 0.5f, 1.0f,
    };

    glMultMatrixf(M);
}

static void mult_camera_P(int ww, int wh, int bw, int bh)
{
    float a = (float) ww / (float) wh;

    float f = get_val_f("camera_far");
    float n = get_val_f("camera_near");
    float z = get_val_f("camera_zoom");

    glFrustum(-z * a, +z * a, -z, +z, n, f);
}

static void mult_camera_R(void)
{
    glRotatef(-get_val_f("camera_phi"),   1.0f, 0.0f, 0.0f);
    glRotatef(-get_val_f("camera_theta"), 0.0f, 1.0f, 0.0f);
}

static void mult_camera_V(void)
{
    glRotatef(-get_val_f("camera_phi"),   1.0f, 0.0f, 0.0f);
    glRotatef(-get_val_f("camera_theta"), 0.0f, 1.0f, 0.0f);

    glTranslatef(-get_val_f("camera_x"),
                 -get_val_f("camera_y"),
                 -get_val_f("camera_z"));
}

static void mult_camera_M(void)
{
    glTranslatef(+get_val_f("camera_x"),
                 +get_val_f("camera_y"),
                 +get_val_f("camera_z"));

    glRotatef(+get_val_f("camera_theta"), 0.0f, 1.0f, 0.0f);
    glRotatef(+get_val_f("camera_phi"),   1.0f, 0.0f, 0.0f);
}

/*---------------------------------------------------------------------------*/

static void mult_light_P(int w, int h)
{
    float a = (float) w / (float) h;

    float f = get_val_f("light_far");
    float n = get_val_f("light_near");
    float z = get_val_f("light_zoom");

    glOrtho(-z * a, +z * a, -z, +z, n, f);
}

static void mult_light_V(void)
{
    glTranslatef(0.0f, 0.0f, -get_val_f("light_dist"));

    glRotatef(-get_val_f("light_phi"),   1.0f, 0.0f, 0.0f);
    glRotatef(-get_val_f("light_theta"), 0.0f, 1.0f, 0.0f);
}

static void mult_light_M(void)
{
    glRotatef(+get_val_f("light_theta"), 0.0f, 1.0f, 0.0f);
    glRotatef(+get_val_f("light_phi"),   1.0f, 0.0f, 0.0f);

    glTranslatef(0.0f, 0.0f, +get_val_f("light_dist"));
 }

static void draw_light_source(void)
{
    float p[4] = { 0.0f, 0.0f, 1.0f, 0.0f };

    glLightfv(GL_LIGHT0, GL_POSITION, p);
}

/*---------------------------------------------------------------------------*/

void draw_light_view(void)
{
    int w = get_val_i("shadow_w");
    int h = get_val_i("shadow_h");

    /* Render the light's view to the shadow buffer. */

    glMatrixMode(GL_PROJECTION);
    {
        glLoadIdentity();
        mult_light_P(w, h);
    }
    glMatrixMode(GL_MODELVIEW);
    
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);

    glViewport(0, 0, w, h);
    clear();

    glPushAttrib(GL_ENABLE_BIT);
    glPushMatrix();
    {
        glDisable(GL_LIGHTING);
        glDisable(GL_TEXTURE_2D);

        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(4.0f, 4.0f);

        draw_light_source();
        mult_light_V();
        draw_objects(DRAW_OBJECTS, 0.0f, 0);
    }
    glPopMatrix();
    glPopAttrib();

    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
}

void draw_scene_view(float dt,
                     int bw, int bh, int flags, float flip, float clip)
{
    /* Set up the view inverse matrix. */

    glActiveTextureARB(GL_TEXTURE5_ARB);
    glMatrixMode(GL_TEXTURE);
    {
        glLoadIdentity();
        glScalef(1.0f, flip, 1.0f);
        mult_camera_M();
    }
    glMatrixMode(GL_MODELVIEW);
    glActiveTextureARB(GL_TEXTURE0_ARB);

    /* Set up the shadow map projection matrix. */

    glMatrixMode(GL_TEXTURE);
    {
        glLoadIdentity();

        mult_camera_S();
        mult_light_P(get_val_i("shadow_w"),
                     get_val_i("shadow_h"));
        mult_light_V();
        glScalef(1.0f, flip, 1.0f);
        mult_camera_M();
    }
    glMatrixMode(GL_MODELVIEW);

    /* Set up the camera projection. */

    glMatrixMode(GL_PROJECTION);
    {
        glLoadIdentity();
        mult_camera_P(get_val_i("window_w"),
                      get_val_i("window_h"), bw, bh);
    }
    glMatrixMode(GL_MODELVIEW);

    /* Draw the sky centered on the camera. */

    if (flags & DRAW_SKY)
    {
        glPushMatrix();
        {
            mult_camera_R();
            glScalef(1.0f, flip, 1.0f);

            glPushMatrix();
            {
                mult_light_M();
                draw_light_source();
            }
            glPopMatrix();

            draw_sky();
        }
        glPopMatrix();
    }

    /* Draw the scene. */

    glPushMatrix();
    {
        mult_camera_V();
        glScalef(1.0f, flip, 1.0f);
        
        glPushMatrix();
        {
            mult_light_M();
            draw_light_source();
        }
        glPopMatrix();

        draw_scene(flags, clip);
    }
    glPopMatrix();

    if (flags & DRAW_WATER)
    {
        /* Set up the reflection/refraction map projection matrix. */

        glMatrixMode(GL_TEXTURE);
        {
            glLoadIdentity();

            mult_camera_S();
            mult_camera_P(get_val_i("window_w"),
                          get_val_i("window_h"), bw, bh);
        }
        glMatrixMode(GL_MODELVIEW);

        /* Draw the water. */

        glPushMatrix();
        {
            mult_camera_V();
        
            glPushMatrix();
            {
                mult_light_M();
                draw_light_source();
            }
            glPopMatrix();

            draw_water(dt, reflect_color, refract_color);
        }
        glPopMatrix();
    }
}

void draw_normal_view(float dt)
{
    int flags = (DRAW_SHADERS | DRAW_LAND | DRAW_OBJECTS |
                 DRAW_SKY | DRAW_GRASS | DRAW_WATER);

    int bw = get_val_i("window_w");
    int bh = get_val_i("window_h");

    glViewport(0, 0, bw, bh);
    clear();

    draw_scene_view(dt, bw, bh, flags, +1.0f, 0.0f);
}

void draw_reflect_view(float dt, float s)
{
    int flags = (DRAW_SHADERS | DRAW_LAND | DRAW_OBJECTS |
                 DRAW_SKY | DRAW_GRASS);

    int bw = get_val_i("buffer_w");
    int bh = get_val_i("buffer_h");

    glViewport(0, 0, bw, bh);
    clear();

    draw_scene_view(dt, bw, bh, flags, s, +1.0f);
}

void draw_refract_view(float dt, float s)
{
    int flags = (DRAW_SHADERS | DRAW_LAND | DRAW_OBJECTS);

    int bw = get_val_i("buffer_w");
    int bh = get_val_i("buffer_h");

    glViewport(0, 0, bw, bh);
    clear();

    draw_scene_view(dt, bw, bh, flags, s, -1.0f);
}

/*---------------------------------------------------------------------------*/

static void init_fbo(GLuint *fbo, GLuint *color, GLuint *depth, int w, int h)
{
    GLenum m = ((w & (w - 1)) && (h & (h - 1))) ? GL_TEXTURE_RECTANGLE_ARB :
                                                  GL_TEXTURE_2D;
        
    /* Generate frame buffer and render buffer objects. */

    glGenFramebuffersEXT(1, fbo);
    glGenTextures       (1, color);
    glGenTextures       (1, depth);

    /* Initialize the color render target. */

    glBindTexture(m, *color);
    glTexImage2D(m, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_INT, NULL);

    glTexParameteri(m, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(m, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(m, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(m, GL_TEXTURE_WRAP_T, GL_CLAMP);

    /* Initialize the depth render target. */

    glBindTexture(m, *depth);
    glTexImage2D(m, 0, GL_DEPTH_COMPONENT24, w, h, 0,
                 GL_DEPTH_COMPONENT, GL_INT, NULL);

    glTexParameteri(m, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(m, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(m, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(m, GL_TEXTURE_WRAP_T, GL_CLAMP);

    /* Initialize the frame buffer object. */

    glBindFramebufferEXT     (GL_FRAMEBUFFER_EXT, *fbo);
    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT,
                              GL_COLOR_ATTACHMENT0_EXT, m, *color, 0);
    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT,
                              GL_DEPTH_ATTACHMENT_EXT, m, *depth, 0);
}

static void free_fbo(GLuint *fbo, GLuint *color, GLuint *depth)
{
    glDeleteFramebuffersEXT(1, fbo);
    glDeleteTextures       (1, color);
    glDeleteTextures       (1, depth);
}

/*---------------------------------------------------------------------------*/

void init_ogl(void)
{
    GLfloat a[4] = { 0.4f, 0.4f, 0.4f };

    int bw = get_val_i("buffer_w");
    int bh = get_val_i("buffer_h");
    int sw = get_val_i("shadow_w");
    int sh = get_val_i("shadow_h");

    /* Set some default OpenGL state. */

    glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, a);
    glLightModeli (GL_LIGHT_MODEL_COLOR_CONTROL,
                   GL_SEPARATE_SPECULAR_COLOR);

    help_map = init_texture("data/help.png");

    /* Generate offscreen render buffers. */

    init_fbo(&shadow_fbo,  &shadow_color,  &shadow_depth,  sw, sh);
    init_fbo(&reflect_fbo, &reflect_color, &reflect_depth, bw, bh);
    init_fbo(&refract_fbo, &refract_color, &refract_depth, bw, bh);

    /* Configure the shadow depth map. */

    glBindTexture(GL_TEXTURE_2D, shadow_depth);
    glTexParameteri(GL_TEXTURE_2D,
                    GL_DEPTH_TEXTURE_MODE_ARB, GL_INTENSITY);
    glTexParameteri(GL_TEXTURE_2D,
                    GL_TEXTURE_COMPARE_MODE_ARB, GL_COMPARE_R_TO_TEXTURE_ARB);
    glTexParameteri(GL_TEXTURE_2D,
                    GL_TEXTURE_COMPARE_FUNC_ARB, GL_LEQUAL);

    init_scene();
}

void draw_ogl(float dt)
{
    /* Render the shadow map. */

    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, shadow_fbo);
    glBindTexture(GL_TEXTURE_2D, 0);
    draw_light_view();

    /* When below the water, the reflect and reflact maps switch roles. */

    if (get_val_f("camera_y") >= 0)
    {
        /* If above the water, render the reflection of the dry land. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, reflect_fbo);
        glBindTexture(GL_TEXTURE_2D, shadow_depth);
        draw_reflect_view(dt, -1.0f);

        /* Render the underwater geometry directly. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, refract_fbo);
        glBindTexture(GL_TEXTURE_2D, shadow_depth);
        draw_refract_view(dt, +1.0f);
    }
    else
    {
        /* If below the water, render the dry land directly. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, reflect_fbo);
        glBindTexture(GL_TEXTURE_2D, shadow_depth);
        draw_reflect_view(dt, +1.0f);

        /* Render the reflection of the underwater geometry.. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, refract_fbo);
        glBindTexture(GL_TEXTURE_2D, shadow_depth);
        draw_refract_view(dt, -1.0f);
    }

    switch (get_val_i("draw_mode") % 4)
    {
    case 0: /* Render the scene normally. */

        step_water(dt);

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
        glBindTexture(GL_TEXTURE_2D, shadow_depth);

        draw_normal_view(dt);
        break;

    case 1: /* Render the shadow buffer to the frame buffer. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
        glBindTexture(GL_TEXTURE_2D, shadow_depth);

        glTexParameteri(GL_TEXTURE_2D,
                        GL_TEXTURE_COMPARE_MODE_ARB,
                        GL_NONE);

        draw_image(get_val_i("shadow_w"),
                   get_val_i("shadow_h"), 1);

        glTexParameteri(GL_TEXTURE_2D,
                        GL_TEXTURE_COMPARE_MODE_ARB,
                        GL_COMPARE_R_TO_TEXTURE_ARB);
        break;

    case 2: /* Render the reflection buffer to the frame buffer. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
        glBindTexture(GL_TEXTURE_2D, reflect_color);

        draw_image(get_val_i("buffer_w"),
                   get_val_i("buffer_h"), 1);
        break;

    case 3: /* Render the refraction buffer to the frame buffer. */

        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
        glBindTexture(GL_TEXTURE_2D, refract_color);

        draw_image(get_val_i("buffer_w"),
                   get_val_i("buffer_h"), 1);
    }

    if (get_val_b("draw_help"))
    {
        glPushAttrib(GL_ENABLE_BIT);
        {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

            glBindTexture(GL_TEXTURE_2D, help_map);
            draw_image(1024, 512, 0);
            glBindTexture(GL_TEXTURE_2D, 0);
        }
        glPopAttrib();
    }
}

void free_ogl(void)
{
    if (help_map) glDeleteTextures(1, &help_map);

    free_fbo(&refract_fbo, &refract_color, &refract_depth);
    free_fbo(&reflect_fbo, &reflect_color, &reflect_depth);
    free_fbo(&shadow_fbo,  &shadow_color,  &shadow_depth);

    free_scene();
}

/*---------------------------------------------------------------------------*/

