#ifndef PHYSICS_H
#define PHYSICS_H

/*---------------------------------------------------------------------------*/

void init_physics(void);
void step_physics(float);
void free_physics(void);

/*---------------------------------------------------------------------------*/

#define MAX_OBJECTS 6

void init_objects(void);
void draw_objects(int, float, GLuint);
void free_objects(void);

void add_object(int, float, float, float);
void get_object(void);
void put_object(float);

void draw_objects_velocity(void);

/*---------------------------------------------------------------------------*/

#endif
