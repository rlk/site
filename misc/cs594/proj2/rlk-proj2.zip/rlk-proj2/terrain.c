#include <stdlib.h>
#include <math.h>

#include "terrain.h"
#include "main.h"
#include "obj.h"

/*---------------------------------------------------------------------------*/

#define OFFSET(i) ((char *) NULL + (i))

#define MAX_GRASS 2048

struct vert
{
    float u[3];
    float n[3];
    float t[2];
    float v[3];
};

static GLuint terrain_prog;
static GLuint terrain_vbo;
static GLuint terrain_ibo;

static GLuint sandy_map;
static GLuint rocky_map;
static GLuint grass_map;
static GLuint blend_map;

static struct vert *V;
static GLushort    *I;
static int          w;
static int          h;

/*---------------------------------------------------------------------------*/

struct point
{
    float t[2];
    float v[3];
};

struct grass
{
    struct point p[3][4];
};

static GLuint grass_prog;
static GLuint grass_vbo;
static GLuint color_map;

static struct grass *G;

/*---------------------------------------------------------------------------*/

static void cross(float z[3], const float x[3], const float y[3])
{
    float t[3];

    t[0] = x[1] * y[2] - x[2] * y[1];
    t[1] = x[2] * y[0] - x[0] * y[2];
    t[2] = x[0] * y[1] - x[1] * y[0];

    z[0] = t[0];
    z[1] = t[1];
    z[2] = t[2];
}

static void normalize(float v[3])
{
    float k = 1.0f / (float) sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);

    v[0] *= k;
    v[1] *= k;
    v[2] *= k;
}

static void normal(float n[3], const float a[3],
                               const float b[3],
                               const float c[3])
{
    float u[3];
    float v[3];

    u[0] = b[0] - a[0];
    u[1] = b[1] - a[1];
    u[2] = b[2] - a[2];

    v[0] = c[0] - a[0];
    v[1] = c[1] - a[1];
    v[2] = c[2] - a[2];

    cross(n, u, v);
    normalize(n);
}

/*---------------------------------------------------------------------------*/

GLuint init_texture(const char *filename)
{
    static const GLenum format[5] = {
        0,
        GL_LUMINANCE,
        GL_LUMINANCE_ALPHA,
        GL_RGB,
        GL_RGBA,
    };

    GLuint o = 0;

    void *p;
    int   w;
    int   h;
    int   b;

    /* Read the image data from the named file to a new pixel buffer. */

    if ((p = obj_read_image(filename, &w, &h, &b)))
    {
        /* Create an OpenGL texture object using these pixels. */

        glGenTextures(1, &o);
        glBindTexture(GL_TEXTURE_2D, o);

        gluBuild2DMipmaps(GL_TEXTURE_2D, format[b], w, h,
                          format[b], GL_UNSIGNED_BYTE, p);

        glTexParameteri(GL_TEXTURE_2D,
                        GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,
                        GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

        /* Discard the unnecessary pixel buffer. */

        free(p);
    }

    return o;
}

/*---------------------------------------------------------------------------*/

static void set_grass(struct point p[4], const float v[3], float a)
{
    float dh =  0.25f;
    float dy =  1.0f + 2.0f * rand() / RAND_MAX;
    float dx =  (float) (cos(a) * dy);
    float dz = -(float) (sin(a) * dy);

    /* Set the texture coordinates. */

    p[0].t[0] = 0;
    p[0].t[1] = 0;

    p[1].t[0] = 1;
    p[1].t[1] = 0;

    p[2].t[0] = 1;
    p[2].t[1] = 1;

    p[3].t[0] = 0;
    p[3].t[1] = 1;

    /* Set the vertex positions. */

    p[0].v[0] = v[0] - dx;
    p[0].v[1] = v[1] - dh;
    p[0].v[2] = v[2] - dz;

    p[1].v[0] = v[0] + dx;
    p[1].v[1] = v[1] - dh;
    p[1].v[2] = v[2] + dz;

    p[2].v[0] = v[0] + dx;
    p[2].v[1] = v[1] - dh + dy;
    p[2].v[2] = v[2] + dz;

    p[3].v[0] = v[0] - dx;
    p[3].v[1] = v[1] - dh + dy;
    p[3].v[2] = v[2] - dz;
}

void init_grass(void)
{
    void *p;
    int   W;
    int   H;
    int   B;
    int   r;
    int   c;
    int   i;

    /* Load the shaders and image maps. */

    grass_prog = make_program("data/grass.vert", "data/grass.frag");
    color_map  = init_texture("data/grass_color_map_256.png");

    glBindTexture(GL_TEXTURE_2D, color_map);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    /* Generate the grass geometry. */

    if ((p = obj_read_image("data/terrain_blend_map_128.png", &W, &H, &B)))
    {
        if ((G = (struct grass *) calloc(MAX_GRASS, sizeof (struct grass))))
        {
            /* Generate MAX_GRASS bits of grass. */

            for (i = 0; i < MAX_GRASS; ++i)
            {
                float   a = 3.14159265f * rand() / RAND_MAX;
                GLubyte k = 0;

                /* Find a random location on a grassy area of the terrain. */

                while (k == 0)
                {
                    r = (int) floor((float) H * rand() / RAND_MAX);
                    c = (int) floor((float) W * rand() / RAND_MAX);

                    k = ((GLubyte *) p)[(W * r + c) * B];
                }

                r = r * h / H;
                c = c * w / W;

                /* Set grass billboards there. */

                set_grass(G[i].p[0], V[w * r + c].v, a);
                set_grass(G[i].p[1], V[w * r + c].v, a + 1.04719755f);
                set_grass(G[i].p[2], V[w * r + c].v, a + 2.09439510f);
            }

            /* Generate a vertex buffer object for the grass geometry. */
        
            glGenBuffersARB(1, &grass_vbo);
            glBindBufferARB(GL_ARRAY_BUFFER_ARB, grass_vbo);
            glBufferDataARB(GL_ARRAY_BUFFER_ARB,
                            MAX_GRASS * sizeof (struct grass), G,
                            GL_STATIC_DRAW_ARB);
        }

        /* Release the temporary blend map buffer. */

        free(p);
    }
}

void draw_grass(float clip)
{
    /* Enable all vertex and index buffer objects and pointers. */

    glBindBufferARB(GL_ARRAY_BUFFER_ARB, grass_vbo);

    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);

    glTexCoordPointer(2, GL_FLOAT, sizeof (struct point), OFFSET(0));
    glVertexPointer  (3, GL_FLOAT, sizeof (struct point), OFFSET(8));

    /* Bind the program object and set the texture and uniforms. */

    glUseProgramObjectARB(grass_prog);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    glBindTexture(GL_TEXTURE_2D, color_map);
    glActiveTextureARB(GL_TEXTURE0_ARB);

    glUniform1iARB(glGetUniformLocationARB(grass_prog, "color_map"), 1);
    glUniform1fARB(glGetUniformLocationARB(grass_prog, "clip"), clip);
    glUniform1fARB(glGetUniformLocationARB(grass_prog, "time"), get_time());
    glUniform3fARB(glGetUniformLocationARB(grass_prog, "wind"),
                                             get_val_f("wind_x"),
                                             get_val_f("wind_y"),
                                             get_val_f("wind_z"));
    /* Draw the grass. */

    glPushAttrib(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
    {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDepthMask(GL_FALSE);

        glNormal3f(0.0f, 1.0f, 0.0f);
        glDrawArrays(GL_QUADS, 0, MAX_GRASS * 12);
    }
    glPopAttrib();

    /* Disable all state. */

    glUseProgramObjectARB(0);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);
    glActiveTextureARB(GL_TEXTURE0_ARB);

    glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);

    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
}

void free_grass(void)
{
    if (grass_prog) glDeleteObjectARB(grass_prog);
    if (grass_vbo)  glDeleteBuffersARB(1, &grass_vbo);

    if (G) free(G);
}

/*---------------------------------------------------------------------------*/

int get_terrain_w(void)
{
    return w;
}

int get_terrain_h(void)
{
    return h;
}

void get_terrain_v(float v[3], int r, int c)
{
    v[0] = V[w * r + c].v[0];
    v[1] = V[w * r + c].v[1];
    v[2] = V[w * r + c].v[2];
}

void get_terrain_n(float n[3], int r, int c)
{
    n[0] = V[w * r + c].n[0];
    n[1] = V[w * r + c].n[1];
    n[2] = V[w * r + c].n[2];
}

/*---------------------------------------------------------------------------*/

static float get_height(const void *p, int r, int c, int w, int h, int b)
{
    const GLubyte *P = (GLubyte *) p;

    int i = CLAMP(r, 0, h - 1);
    int j = CLAMP(c, 0, w - 1);

    return (float) P[((i * w) + j) * b] / 255.0f;
}

void init_terrain(void)
{
    /* 5x5 Gaussian convolution kernel. */

    static const float K[5][5] = {
        {  1.0f,  4.0f,  7.0f,  4.0f,  1.0f },
        {  4.0f, 16.0f, 26.0f, 16.0f,  4.0f },
        {  7.0f, 26.0f, 41.0f, 26.0f,  7.0f },
        {  4.0f, 16.0f, 26.0f, 16.0f,  4.0f },
        {  1.0f,  4.0f,  7.0f,  4.0f,  1.0f },
    };

    void *p;
    int   b;
    int   r;
    int   c;
    int   i;
    int   j;

    /* Load the shaders and image maps. */

    terrain_prog = make_program("data/terrain.vert", "data/terrain.frag");

    blend_map = init_texture("data/terrain_blend_map_128.png");

    if (get_val_i("optimization") > 0)
    {
        sandy_map = init_texture("data/terrain_sandy_map_512.png");
        rocky_map = init_texture("data/terrain_rocky_map_512.png");
        grass_map = init_texture("data/terrain_grass_map_512.png");
    }
    else
    {
        sandy_map = init_texture("data/terrain_sandy_map_1024.png");
        rocky_map = init_texture("data/terrain_rocky_map_1024.png");
        grass_map = init_texture("data/terrain_grass_map_1024.png");
    }

    /* Load the height map. */

    if ((p = obj_read_image("data/terrain_height_map_128.png", &w, &h, &b)))
    {
        /* Generate vertices from the image data. */

        if ((V = (struct vert *) calloc(w * h, sizeof (struct vert))))
        {
            struct vert *v;

            /* Generate terrain vertices. */

            for (v = V, r = 0; r < h; ++r)
                for (c = 0; c < w; ++c, ++v)
                {
                    float k = 0.0f;

                    /* Filter heights to soften the 8-bit quantization. */

                    for (i = 0; i < 5; ++i)
                        for (j = 0; j < 5; ++j)
                            k += get_height(p, r + i - 2,
                                               c + j - 2, w, h, b) * K[i][j];

                    k /= 273.0f;

                    /* Compute vertex positions and texture coordinates. */

                    v->v[0] =  TERRAIN_W * ((float) c / w - 0.5f);
                    v->v[1] =  TERRAIN_D * k + TERRAIN_0;
                    v->v[2] = -TERRAIN_H * ((float) r / h - 0.5f);

                    v->t[0] = (float) c / w;
                    v->t[1] = (float) r / h;
                }

            /* Compute terrain normals. */

            for (r = 0; r < h - 1; ++r)
                for (c = 0; c < w - 1; ++c)
                {
                    int i = (r + 0) * w + (c + 0);
                    int j = (r + 0) * w + (c + 1);
                    int k = (r + 1) * w + (c + 1);
                    int l = (r + 1) * w + (c + 0);

                    float n[3];

                    normal(n, V[i].v, V[j].v, V[k].v);

                    V[i].n[0] += n[0]; V[i].n[1] += n[1]; V[i].n[2] += n[2];
                    V[j].n[0] += n[0]; V[j].n[1] += n[1]; V[j].n[2] += n[2];
                    V[k].n[0] += n[0]; V[k].n[1] += n[1]; V[k].n[2] += n[2];

                    normal(n, V[k].v, V[l].v, V[i].v);

                    V[k].n[0] += n[0]; V[k].n[1] += n[1]; V[k].n[2] += n[2];
                    V[l].n[0] += n[0]; V[l].n[1] += n[1]; V[l].n[2] += n[2];
                    V[i].n[0] += n[0]; V[i].n[1] += n[1]; V[i].n[2] += n[2];
                }

            /* Compute tangent space vectors. */

            for (i = 0; i < w * h; ++i)
            {
                const float Z[3] = { 0.0, 0.0, -1.0 };

                normalize(V[i].n);
                cross(V[i].u, V[i].n, Z);
                normalize(V[i].u);
            }

            /* Apply the vertices to a vertex buffer object. */

            glGenBuffersARB(1, &terrain_vbo);
            glBindBufferARB(GL_ARRAY_BUFFER_ARB, terrain_vbo);
            glBufferDataARB(GL_ARRAY_BUFFER_ARB,
                            w * h * sizeof (struct vert), V,
                            GL_STATIC_DRAW_ARB);
        }

        /* Generate an index buffer object. */

        if ((I = (GLushort *) calloc((2 * w) * (h - 1), sizeof (GLushort))))
        {
            for (i = 0, r = 0; r < h - 1; ++r)
                for (c = 0; c < w; ++c)
                {
                    I[i++] = (GLushort) ((r + 1) * w + c);
                    I[i++] = (GLushort) ((r + 0) * w + c);
                }
            glGenBuffersARB(1, &terrain_ibo);
            glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, terrain_ibo);
            glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB,
                            (2 * w) * (h - 1) * sizeof (GLushort), I,
                            GL_STATIC_DRAW_ARB);
        }

        /* Release the temporary pixel buffer. */

        free(p);
    }

    init_grass();
}

void draw_terrain(int flags, float clip, GLuint water_map)
{
    GLsizei size = sizeof (struct vert);
    int r;

    /* Enable all vertex and index buffer objects and pointers. */

    glBindBufferARB(GL_ARRAY_BUFFER_ARB,         terrain_vbo);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, terrain_ibo);

    glEnableVertexAttribArrayARB(6);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);

    glVertexAttribPointerARB(6, 3, GL_FLOAT, 0, size, OFFSET( 0));
    glNormalPointer         (      GL_FLOAT,    size, OFFSET(12));
    glTexCoordPointer       (2,    GL_FLOAT,    size, OFFSET(24));
    glVertexPointer         (3,    GL_FLOAT,    size, OFFSET(32));

    /* Bind all texture maps. */

    glMatrixMode(GL_TEXTURE);
    {
        float x = 16.0f;
        float y = 16.0f;
        float z = 16.0f;

        glActiveTextureARB(GL_TEXTURE1_ARB);
        glBindTexture(GL_TEXTURE_2D, blend_map);
        glLoadIdentity();

        glActiveTextureARB(GL_TEXTURE2_ARB);
        glBindTexture(GL_TEXTURE_2D, grass_map);
        glLoadIdentity();
        glScalef(1.0f * x, 1.0f * y, 1.0f * z);

        glActiveTextureARB(GL_TEXTURE3_ARB);
        glBindTexture(GL_TEXTURE_2D, sandy_map);
        glLoadIdentity();
        glScalef(0.7f * x, 0.7f * y, 0.7f * z);

        glActiveTextureARB(GL_TEXTURE4_ARB);
        glBindTexture(GL_TEXTURE_2D, rocky_map);
        glLoadIdentity();
        glScalef(0.5f * x, 0.5f * y, 0.5f * z);

        glActiveTextureARB(GL_TEXTURE5_ARB);
        glBindTexture(GL_TEXTURE_2D, water_map);

        glActiveTextureARB(GL_TEXTURE0_ARB);
    }
    glMatrixMode(GL_MODELVIEW);

    /* Bind the program object and set the uniforms. */

    glUseProgramObjectARB(terrain_prog);

    glUniform1iARB(glGetUniformLocationARB(terrain_prog, "shadow_map"), 0);
    glUniform1iARB(glGetUniformLocationARB(terrain_prog, "blend_map"),  1);
    glUniform1iARB(glGetUniformLocationARB(terrain_prog, "grass_map"),  2);
    glUniform1iARB(glGetUniformLocationARB(terrain_prog, "sandy_map"),  3);
    glUniform1iARB(glGetUniformLocationARB(terrain_prog, "rocky_map"),  4);
    glUniform1iARB(glGetUniformLocationARB(terrain_prog, "water_map"),  5);
    glUniform1fARB(glGetUniformLocationARB(terrain_prog, "clip"), clip);

    glUniform1fARB(glGetUniformLocationARB(terrain_prog, "mud_coeff"),
                                               get_val_f("mud_coeff"));
    glUniform4fARB(glGetUniformLocationARB(terrain_prog, "mud_color"),
                                               get_val_f("mud_color_r"),
                                               get_val_f("mud_color_g"),
                                               get_val_f("mud_color_b"), 1.0f);

    /* Draw the terrain. */

    if (flags & DRAW_LAND)
        for (r = 0; r < h - 1; ++r)
            glDrawElements(GL_TRIANGLE_STRIP, 2 * (w - 1),
                           GL_UNSIGNED_SHORT,
                           OFFSET(2 * w * r * sizeof (GLushort)));

    /* Disable all state. */

    glUseProgramObjectARB(0);

    glMatrixMode(GL_TEXTURE);
    {
        glActiveTextureARB(GL_TEXTURE1_ARB);
        glBindTexture(GL_TEXTURE_2D, 0);
        glLoadIdentity();

        glActiveTextureARB(GL_TEXTURE2_ARB);
        glBindTexture(GL_TEXTURE_2D, 0);
        glLoadIdentity();

        glActiveTextureARB(GL_TEXTURE3_ARB);
        glBindTexture(GL_TEXTURE_2D, 0);
        glLoadIdentity();

        glActiveTextureARB(GL_TEXTURE4_ARB);
        glBindTexture(GL_TEXTURE_2D, 0);
        glLoadIdentity();

        glActiveTextureARB(GL_TEXTURE5_ARB);
        glBindTexture(GL_TEXTURE_2D, 0);

        glActiveTextureARB(GL_TEXTURE0_ARB);
    }
    glMatrixMode(GL_MODELVIEW);

    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);

    glBindBufferARB(GL_ARRAY_BUFFER_ARB,         0);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);

    if (flags & DRAW_GRASS) draw_grass(clip);
}

void draw_terrain_clamp(void)
{
    GLsizei size = sizeof (struct vert);
    int r;

    /* Enable all vertex and index buffer objects and pointers. */

    glBindBufferARB(GL_ARRAY_BUFFER_ARB,         terrain_vbo);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, terrain_ibo);

    glEnableClientState(GL_VERTEX_ARRAY);

    glVertexPointer(3, GL_FLOAT, size, OFFSET(32));

    /* Draw the terrain. */

    for (r = 0; r < h - 1; ++r)
        glDrawElements(GL_TRIANGLE_STRIP, 2 * (w - 1),
                       GL_UNSIGNED_SHORT,
                       OFFSET(2 * w * r * sizeof (GLushort)));

    /* Disable all state. */

    glDisableClientState(GL_VERTEX_ARRAY);

    glBindBufferARB(GL_ARRAY_BUFFER_ARB,         0);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
}

void free_terrain(void)
{
    if (terrain_prog) glDeleteObjectARB(terrain_prog);
    if (terrain_vbo)  glDeleteBuffersARB(1, &terrain_vbo);
    if (terrain_ibo)  glDeleteBuffersARB(1, &terrain_ibo);

    if (I) free(I);
    if (V) free(V);

    free_grass();
}

/*---------------------------------------------------------------------------*/
