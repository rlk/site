#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <SDL.h>
#include <SDL_thread.h>
#include <png.h>

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

#include "main.h"

/*---------------------------------------------------------------------------*/

#define GRAB 1

#define TITLE "OpenGL"
#define MIN_W 80
#define MIN_H 60
#define JIFFY (1.0f / 60.0f)

static SDL_sem   *sem;
static lua_State *lua;

extern void step_physics(float);

extern void init_lua(void);
extern void init_ogl(void);
extern void draw_ogl(float);
extern void free_ogl(void);

/*---------------------------------------------------------------------------*/

static void lua_function(lua_State *L, const char *name, lua_CFunction func)
{
    lua_pushstring(L, name);
    lua_pushstring(L, name);
    lua_pushcclosure(L, func, 1);
    lua_settable(L, LUA_GLOBALSINDEX);
}

/*===========================================================================*/
/* OpenGL State                                                              */

#ifndef __APPLE__
PFNGLGETOBJECTPARAMETERIVARBPROC     glGetObjectParameterivARB;
PFNGLGETUNIFORMLOCATIONARBPROC       glGetUniformLocationARB;
PFNGLBINDATTRIBLOCATIONARBPROC       glBindAttribLocationARB;
PFNGLUSEPROGRAMOBJECTARBPROC         glUseProgramObjectARB;
PFNGLCREATESHADEROBJECTARBPROC       glCreateShaderObjectARB;
PFNGLCREATEPROGRAMOBJECTARBPROC      glCreateProgramObjectARB;
PFNGLVALIDATEPROGRAMARBPROC          glValidateProgramARB;
PFNGLSHADERSOURCEARBPROC             glShaderSourceARB;
PFNGLCOMPILESHADERARBPROC            glCompileShaderARB;
PFNGLATTACHOBJECTARBPROC             glAttachObjectARB;
PFNGLLINKPROGRAMARBPROC              glLinkProgramARB;
PFNGLGETINFOLOGARBPROC               glGetInfoLogARB;
PFNGLDELETEOBJECTARBPROC             glDeleteObjectARB;
PFNGLUNIFORM1IARBPROC                glUniform1iARB;
PFNGLUNIFORM1FARBPROC                glUniform1fARB;
PFNGLUNIFORM2FARBPROC                glUniform2fARB;
PFNGLUNIFORM3FARBPROC                glUniform3fARB;
PFNGLUNIFORM4FARBPROC                glUniform4fARB;
PFNGLUNIFORMMATRIX3FVARBPROC         glUniformMatrix3fvARB;
PFNGLGENFRAMEBUFFERSEXTPROC          glGenFramebuffersEXT;
PFNGLGENRENDERBUFFERSEXTPROC         glGenRenderbuffersEXT;
PFNGLDELETEFRAMEBUFFERSEXTPROC       glDeleteFramebuffersEXT;
PFNGLDELETERENDERBUFFERSEXTPROC      glDeleteRenderbuffersEXT;
PFNGLBINDFRAMEBUFFEREXTPROC          glBindFramebufferEXT;
PFNGLBINDRENDERBUFFEREXTPROC         glBindRenderbufferEXT;
PFNGLFRAMEBUFFERTEXTURE2DEXTPROC     glFramebufferTexture2DEXT;
PFNGLFRAMEBUFFERRENDERBUFFEREXTPROC  glFramebufferRenderbufferEXT;
PFNGLRENDERBUFFERSTORAGEEXTPROC      glRenderbufferStorageEXT;
PFNGLENABLEVERTEXATTRIBARRAYARBPROC  glEnableVertexAttribArrayARB;
PFNGLDISABLEVERTEXATTRIBARRAYARBPROC glDisableVertexAttribArrayARB;
PFNGLVERTEXATTRIBPOINTERARBPROC      glVertexAttribPointerARB;
PFNGLGENBUFFERSARBPROC               glGenBuffersARB;
PFNGLBINDBUFFERARBPROC               glBindBufferARB;
PFNGLMAPBUFFERARBPROC                glMapBufferARB;
PFNGLUNMAPBUFFERARBPROC              glUnmapBufferARB;
PFNGLBUFFERDATAARBPROC               glBufferDataARB;
PFNGLDELETEBUFFERSARBPROC            glDeleteBuffersARB;
PFNGLACTIVETEXTUREARBPROC            glActiveTextureARB;
PFNGLTEXIMAGE3DEXTPROC               glTexImage3DEXT;
#endif

GLboolean GL_has_ARB_shader_objects;
GLboolean GL_has_ARB_fragment_shader;
GLboolean GL_has_ARB_vertex_shader;
GLboolean GL_has_ARB_vertex_buffer_object;
GLboolean GL_has_EXT_framebuffer_object;

/*---------------------------------------------------------------------------*/

#define CHECK_VAL(e) check_val(e, #e)

void check_val(GLenum e, const char *str)
{
    GLint d;

    glGetIntegerv(e, &d);
    printf("%-64s %8d\n", str, d);
}

void check_err(const char *str)
{
    static int halted = 0;
    GLenum err;
    
    /* Dump a GL error message, if any.  Report only one error. */

    if (halted == 0 && (err = glGetError()) != GL_NO_ERROR)
    {
        fprintf(stderr, "%s: %s\n", str, gluErrorString(err));
        halted = 1;
    }
}

void check_log(GLhandleARB handle)
{
    char *log;
    GLint len;

    /* Dump the contents of the log, if any. */

    glGetObjectParameterivARB(handle, GL_OBJECT_INFO_LOG_LENGTH_ARB, &len);

    if ((len > 1) && (log = (char *) malloc(len + 1)))
    {
        glGetInfoLogARB(handle, len, NULL, log);

        fprintf(stderr, log);
        free(log);
    }
}

void validate(GLhandleARB handle)
{
    GLint status;

    /* Validate the given program against the current state. */

    glValidateProgramARB(handle);
    glGetObjectParameterivARB(handle, GL_OBJECT_VALIDATE_STATUS_ARB, &status);

    if (status == 0)
        check_log(handle);
}

/*---------------------------------------------------------------------------*/

static GLboolean gl_ext(const char *needle)
{
    const GLubyte *haystack, *c;

    for (haystack = glGetString(GL_EXTENSIONS); *haystack; haystack++)
    {
        for (c = (const GLubyte *) needle; *c && *haystack; c++, haystack++)
            if (*c != *haystack)
                break;

        if ((*c == 0) && (*haystack == ' ' || *haystack == '\0'))
            return GL_TRUE;
    }

    fprintf(stderr, "Missing GL extension %s\n", needle);

    return GL_FALSE;
}

static void init_ext(void)
{
#ifndef __APPLE__
    glGetObjectParameterivARB     = (PFNGLGETOBJECTPARAMETERIVARBPROC)
                      glGetProcAddress("glGetObjectParameterivARB");
    glGetUniformLocationARB       = (PFNGLGETUNIFORMLOCATIONARBPROC)
                      glGetProcAddress("glGetUniformLocationARB");
    glBindAttribLocationARB       = (PFNGLBINDATTRIBLOCATIONARBPROC)
                      glGetProcAddress("glBindAttribLocationARB");
    glUseProgramObjectARB         = (PFNGLUSEPROGRAMOBJECTARBPROC)
                      glGetProcAddress("glUseProgramObjectARB");
    glCreateShaderObjectARB       = (PFNGLCREATESHADEROBJECTARBPROC)
                      glGetProcAddress("glCreateShaderObjectARB");
    glCreateProgramObjectARB      = (PFNGLCREATEPROGRAMOBJECTARBPROC)
                      glGetProcAddress("glCreateProgramObjectARB");
    glValidateProgramARB          = (PFNGLVALIDATEPROGRAMARBPROC)
                      glGetProcAddress("glValidateProgramARB");
    glShaderSourceARB             = (PFNGLSHADERSOURCEARBPROC)
                      glGetProcAddress("glShaderSourceARB");
    glCompileShaderARB            = (PFNGLCOMPILESHADERARBPROC)
                      glGetProcAddress("glCompileShaderARB");
    glAttachObjectARB             = (PFNGLATTACHOBJECTARBPROC)
                      glGetProcAddress("glAttachObjectARB");
    glLinkProgramARB              = (PFNGLLINKPROGRAMARBPROC)
                      glGetProcAddress("glLinkProgramARB");
    glGetInfoLogARB               = (PFNGLGETINFOLOGARBPROC)
                      glGetProcAddress("glGetInfoLogARB");
    glDeleteObjectARB             = (PFNGLDELETEOBJECTARBPROC)
                      glGetProcAddress("glDeleteObjectARB");
    glUniform1iARB                = (PFNGLUNIFORM1IARBPROC)
                      glGetProcAddress("glUniform1iARB");
    glUniform1fARB                = (PFNGLUNIFORM1FARBPROC)
                      glGetProcAddress("glUniform1fARB");
    glUniform2fARB                = (PFNGLUNIFORM2FARBPROC)
                      glGetProcAddress("glUniform2fARB");
    glUniform3fARB                = (PFNGLUNIFORM3FARBPROC)
                      glGetProcAddress("glUniform3fARB");
    glUniform4fARB                = (PFNGLUNIFORM4FARBPROC)
                      glGetProcAddress("glUniform4fARB");
    glUniformMatrix3fvARB         = (PFNGLUNIFORMMATRIX3FVARBPROC)
                      glGetProcAddress("glUniformMatrix3fvARB");
    glGenFramebuffersEXT          = (PFNGLGENFRAMEBUFFERSEXTPROC)
                      glGetProcAddress("glGenFramebuffersEXT");
    glGenRenderbuffersEXT         = (PFNGLGENRENDERBUFFERSEXTPROC)
                      glGetProcAddress("glGenRenderbuffersEXT");
    glDeleteFramebuffersEXT       = (PFNGLDELETEFRAMEBUFFERSEXTPROC)
                      glGetProcAddress("glDeleteFramebuffersEXT");
    glDeleteRenderbuffersEXT      = (PFNGLDELETERENDERBUFFERSEXTPROC)
                      glGetProcAddress("glDeleteRenderbuffersEXT");
    glBindFramebufferEXT          = (PFNGLBINDFRAMEBUFFEREXTPROC)
                      glGetProcAddress("glBindFramebufferEXT");
    glBindRenderbufferEXT         = (PFNGLBINDRENDERBUFFEREXTPROC)
                      glGetProcAddress("glBindRenderbufferEXT");
    glFramebufferTexture2DEXT     = (PFNGLFRAMEBUFFERTEXTURE2DEXTPROC)
                      glGetProcAddress("glFramebufferTexture2DEXT");
    glFramebufferRenderbufferEXT  = (PFNGLFRAMEBUFFERRENDERBUFFEREXTPROC)
                      glGetProcAddress("glFramebufferRenderbufferEXT");
    glRenderbufferStorageEXT      = (PFNGLRENDERBUFFERSTORAGEEXTPROC)
                      glGetProcAddress("glRenderbufferStorageEXT");
    glEnableVertexAttribArrayARB  = (PFNGLENABLEVERTEXATTRIBARRAYARBPROC)
                      glGetProcAddress("glEnableVertexAttribArrayARB");
    glDisableVertexAttribArrayARB = (PFNGLDISABLEVERTEXATTRIBARRAYARBPROC)
                      glGetProcAddress("glDisableVertexAttribArrayARB");
    glVertexAttribPointerARB      = (PFNGLVERTEXATTRIBPOINTERARBPROC)
                      glGetProcAddress("glVertexAttribPointerARB");
    glGenBuffersARB               = (PFNGLGENBUFFERSARBPROC)
                      glGetProcAddress("glGenBuffersARB");
    glBindBufferARB               = (PFNGLBINDBUFFERARBPROC)
                      glGetProcAddress("glBindBufferARB");
    glMapBufferARB                = (PFNGLMAPBUFFERARBPROC)
                      glGetProcAddress("glMapBufferARB");
    glUnmapBufferARB              = (PFNGLUNMAPBUFFERARBPROC)
                      glGetProcAddress("glUnmapBufferARB");
    glBufferDataARB               = (PFNGLBUFFERDATAARBPROC)
                      glGetProcAddress("glBufferDataARB");
    glDeleteBuffersARB            = (PFNGLDELETEBUFFERSARBPROC)
                      glGetProcAddress("glDeleteBuffersARB");
    glActiveTextureARB            = (PFNGLACTIVETEXTUREARBPROC)
                      glGetProcAddress("glActiveTextureARB");
    glTexImage3DEXT               = (PFNGLTEXIMAGE3DEXTPROC)
                      glGetProcAddress("glTexImage3DEXT");
#endif

    GL_has_ARB_shader_objects       = gl_ext("ARB_shader_objects");
    GL_has_ARB_fragment_shader      = gl_ext("ARB_fragment_shader");
    GL_has_ARB_vertex_shader        = gl_ext("ARB_vertex_shader");
    GL_has_ARB_vertex_buffer_object = gl_ext("ARB_vertex_buffer_object");
    GL_has_EXT_framebuffer_object   = gl_ext("EXT_framebuffer_object");

/*
    CHECK_VAL(GL_MAX_TEXTURE_UNITS_ARB);
    CHECK_VAL(GL_MAX_VERTEX_UNIFORM_COMPONENTS_ARB);
    CHECK_VAL(GL_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB);
    CHECK_VAL(GL_MAX_VARYING_FLOATS_ARB);
    CHECK_VAL(GL_MAX_VERTEX_ATTRIBS_ARB);
    CHECK_VAL(GL_MAX_TEXTURE_IMAGE_UNITS_ARB);
    CHECK_VAL(GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS);
    CHECK_VAL(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS);
    CHECK_VAL(GL_MAX_TEXTURE_COORDS_ARB);
*/
}

/*---------------------------------------------------------------------------*/

static GLhandleARB make_shader(const char *filename, GLenum type)
{
    GLhandleARB handle = 0;

    FILE *fin;
    GLint len;
    char *buf;

    if (filename && (fin = fopen(filename, "r")))
    {
        /* Determine the file length. */

        fseek(fin, 0L, SEEK_END);
        len = (int) ftell(fin);
        fseek(fin, 0L, SEEK_SET);

        /* Allocate a text buffer and read the file to it. */

        if ((buf = (char *) malloc(len)))
        {
            GLint status;

            fread(buf, 1, len, fin);

            /* Create a shader object and compile the source. */

            handle = glCreateShaderObjectARB(type);

            glShaderSourceARB (handle, 1, (const GLcharARB **) &buf, &len);
            glCompileShaderARB(handle);

            glGetObjectParameterivARB(handle,
                                      GL_OBJECT_COMPILE_STATUS_ARB, &status);
            if (status == 0)
            {
                check_err("Compile");
                check_log(handle);
            }
            free(buf);
        }
        fclose(fin);
    }
    return handle;
}

GLhandleARB make_program(const char *vert_txt, const char *frag_txt)
{
    if (GL_has_ARB_shader_objects)
    {
        GLint status;

        /* Create program and shader objects. */

        GLhandleARB handle = glCreateProgramObjectARB();

        GLhandleARB vert = make_shader(vert_txt, GL_VERTEX_SHADER_ARB);
        GLhandleARB frag = make_shader(frag_txt, GL_FRAGMENT_SHADER_ARB);

        /* Assume vertex attribute 6 gives tangent vectors. */

/*      glBindAttribLocationARB(handle, 6, "obj_Tangent"); */

        /* Attach the shaders and link the program. */

        if (vert) glAttachObjectARB(handle, vert);
        if (frag) glAttachObjectARB(handle, frag);

        glLinkProgramARB(handle);

        glGetObjectParameterivARB(handle,
                                  GL_OBJECT_LINK_STATUS_ARB, &status);
        if (status == 0)
        {
            check_err("Link");
            check_log(handle);
        }
        return handle;
    }
    return 0;
}

/*===========================================================================*/

void snap(char *filename)
{
    FILE       *filep  = NULL;
    png_structp writep = NULL;
    png_infop   infop  = NULL;
    png_bytep  *bytep  = NULL;

    int w = MAX(get_val_i("window_w"), MIN_W);
    int h = MAX(get_val_i("window_h"), MIN_H);
    int i;

    unsigned char *p = NULL;

    /* Initialize all PNG export data structures. */

    if (!(filep = fopen(filename, "wb")))
        return;
    if (!(writep = png_create_write_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0)))
        return;
    if (!(infop = png_create_info_struct(writep)))
        return;

    /* Enable the default PNG error handler. */

    if (setjmp(png_jmpbuf(writep)) == 0)
    {
        /* Initialize the PNG header. */

        png_init_io (writep, filep);
        png_set_IHDR(writep, infop, w, h, 8,
                     PNG_COLOR_TYPE_RGB,
                     PNG_INTERLACE_NONE,
                     PNG_COMPRESSION_TYPE_DEFAULT,
                     PNG_FILTER_TYPE_DEFAULT);

        /* Allocate the pixel buffer and copy pixels there. */

        if ((p = (unsigned char *) malloc(w * h * 4)))
        {
            glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, p);

            /* Allocate and initialize the row pointers. */

            if ((bytep = png_malloc(writep, h * sizeof (png_bytep))))
            {
                for (i = 0; i < h; ++i)
                    bytep[h - i - 1] = (png_bytep) (p + i * w * 3);

                png_set_rows (writep, infop, bytep);

                /* Write the PNG image file. */

                png_write_info(writep, infop);
                png_write_png (writep, infop, 0, NULL);

                free(bytep);
            }
            free(p);
        }
    }

    /* Release all resources. */

    png_destroy_write_struct(&writep, &infop);
    fclose(filep);
}

static void show_fps(void)
{
    static float now  = 0.0f;
    static float then = 0.0f;
    static int   num  = 0;

    now  = (float) SDL_GetTicks() / 1000.f;
    num += 1;

    /* Compute and display the average frames-per-second value. */

    if (now - then > 0.5f)
    {
        char str[64];

        sprintf(str, "%s - %d fps", TITLE, (int) (num / (now - then)));

        then = now;
        num  = 0;

        SDL_WM_SetCaption(str, str);
    }
}


/*===========================================================================*/

static int time_passing = 1;

float get_time(void)
{
    static float now  = 0.0f;
    static float then = 0.0f;
    static float time = 0.0f;

    now = (float) SDL_GetTicks() / 1000.0f;

    if (time_passing)
        time = time + now - then;

    then = now;

    return time;
}

float get_val_f(const char *name)
{
    float f = 0.0f;

    lua_pushstring(lua, name);
    lua_gettable  (lua, LUA_GLOBALSINDEX);

    if (lua_isnumber(lua, -1))
        f = (float) lua_tonumber(lua, -1);

    lua_pop(lua, 1);

    return f;
}

int get_val_i(const char *name)
{
    int i = 0;

    lua_pushstring(lua, name);
    lua_gettable  (lua, LUA_GLOBALSINDEX);

    if (lua_isnumber(lua, -1))
        i = (int) lua_tonumber(lua, -1);

    lua_pop(lua, 1);

    return i;
}

int get_val_b(const char *name)
{
    int b = 0;

    lua_pushstring(lua, name);
    lua_gettable  (lua, LUA_GLOBALSINDEX);

    if (lua_isboolean(lua, -1))
        b = (int) lua_toboolean(lua, -1);

    lua_pop(lua, 1);

    return b;
}

/*---------------------------------------------------------------------------*/

void set_val_f(const char *name, float f)
{
    lua_pushstring(lua, name);
    lua_pushnumber(lua, f);
    lua_settable  (lua, LUA_GLOBALSINDEX);
}

void set_val_i(const char *name, int i)
{
    lua_pushstring(lua, name);
    lua_pushnumber(lua, i);
    lua_settable  (lua, LUA_GLOBALSINDEX);
}

void set_val_b(const char *name, int b)
{
    lua_pushstring (lua, name);
    lua_pushboolean(lua, b);
    lua_settable   (lua, LUA_GLOBALSINDEX);
}

/*---------------------------------------------------------------------------*/

static int grabbed = 0;

static void grab(void)
{
	if (!grabbed)
	{
        SDL_WM_GrabInput(SDL_GRAB_ON);
        SDL_ShowCursor(SDL_DISABLE);

		grabbed = 1;
	}
}

static void ungrab(void)
{
	if (grabbed)
	{
        SDL_ShowCursor(SDL_ENABLE);
        SDL_WM_GrabInput(SDL_GRAB_OFF);

		grabbed = 0;
	}
}

static void toggle_grab(void)
{
	if (grabbed)
		ungrab();
	else
		grab();
}

/*---------------------------------------------------------------------------*/

static void eval(const char *cmd)
{
    size_t sz = strlen((const char *) cmd);

    /* Evaluate the given string as a Lua expression. */

    if (luaL_loadbuffer(lua, cmd, sz, cmd) || lua_pcall(lua, 0, 0, 0))
    {
#ifndef _WIN32
        fprintf(stderr, "%s\n", lua_tostring(lua, -1));
#endif
        lua_pop(lua, 1);
    }
}

static void do_input(void *data)
{
    /* Evaluate and free the input. Signal the console thread to proceed. */

    eval(data);
    free(data);
    SDL_SemPost(sem);
}

static void do_timer(float dt)
{
    /* Evaluate the timer handler function, if defined. */

    lua_getglobal(lua, "do_timer");

    if (lua_isfunction(lua, -1))
    {
        lua_pushnumber(lua, (lua_Number) dt);

        if (lua_pcall(lua, 1, 0, 0))
        {
            fprintf(stderr, "%s\n", lua_tostring(lua, -1));
            lua_pop(lua, 1);
        }
    }
    else lua_pop(lua, 1);
}

static void do_point(int x, int y)
{
    /* Evaluate the point handler function, if defined. */

    lua_getglobal(lua, "do_point");

    if (lua_isfunction(lua, -1))
    {
        lua_pushnumber(lua, (lua_Number) x);
        lua_pushnumber(lua, (lua_Number) y);

        if (lua_pcall(lua, 2, 0, 0))
        {
            fprintf(stderr, "%s\n", lua_tostring(lua, -1));
            lua_pop(lua, 1);
        }
    }
    else lua_pop(lua, 1);
}

static void do_click(int x, int y, int b, int s)
{
    /* Evaluate the click handler function, if defined. */

    lua_getglobal(lua, "do_click");

    if (lua_isfunction(lua, -1))
    {
        lua_pushnumber (lua, (lua_Number) x);
        lua_pushnumber (lua, (lua_Number) y);
        lua_pushnumber (lua, (lua_Number) b);
        lua_pushboolean(lua, s);

        if (lua_pcall(lua, 4, 0, 0))
        {
            fprintf(stderr, "%s\n", lua_tostring(lua, -1));
            lua_pop(lua, 1);
        }
    }
    else lua_pop(lua, 1);
}

static void do_key(int c, int s)
{
    if (s && c == SDLK_SPACE)
		toggle_grab();

    if (s && c == SDLK_F9)
		snap("snap.png");

	if (s && c == SDLK_ESCAPE)
	{
		set_val_b("looping", 0);
		set_val_b("running", 0);
	}

    /* Evaluate the keyboard handler function, if defined. */

    lua_getglobal(lua, "do_key");

    if (lua_isfunction(lua, -1))
    {
        lua_pushnumber (lua, (lua_Number) c);
        lua_pushboolean(lua, s);

        if (lua_pcall(lua, 2, 0, 0))
        {
            fprintf(stderr, "%s\n", lua_tostring(lua, -1));
            lua_pop(lua, 1);
        }
    }
    else lua_pop(lua, 1);
}

/*---------------------------------------------------------------------------*/

static int lua_add_object(lua_State *lua)
{
    extern void add_object(int, float, float, float);

    add_object((int)   lua_tonumber(lua, -4),
               (float) lua_tonumber(lua, -3),
               (float) lua_tonumber(lua, -2),
               (float) lua_tonumber(lua, -1));

    return 0;
}

static int lua_get_object(lua_State *lua)
{
    extern void get_object(void);

    get_object();
    return 0;
}

static int lua_put_object(lua_State *lua)
{
    extern void put_object(float);

    put_object((float) lua_tonumber(lua, -1));
    return 0;
}

/*---------------------------------------------------------------------------*/

static int do_video(int argc, char *argv[])
{
    int x = 0;
    int y = 0;

    set_val_b("running", 1);

    while (get_val_b("running"))
    {
        int w = MAX(get_val_i("window_w"), MIN_W);
        int h = MAX(get_val_i("window_h"), MIN_H);
        int m = SDL_OPENGL | (get_val_b("fullscreen") ? SDL_FULLSCREEN : 0);

        set_val_b("looping", 1);

        SDL_GL_SetAttribute(SDL_GL_RED_SIZE,     8);
        SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE,   8);
        SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE,    8);
        SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE,   8);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,  16);
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
        
        if (SDL_SetVideoMode(w, h, 0, m))
        {
            float now  = 0.0f;
            float then = 0.0f;

            SDL_Event e;
            SDL_WM_SetCaption(TITLE, TITLE);

            init_ext();
            init_ogl();
			grab();

            while (get_val_b("running") && get_val_b("looping"))
            {
                /* Process all pending events. */

                while (SDL_PollEvent(&e))
                    switch (e.type)
                    {
                    case SDL_USEREVENT:
                        do_input(e.user.data1);
                        break;
                    case SDL_MOUSEMOTION:
                        do_point((x = e.motion.xrel),
                                 (y = e.motion.yrel));
                        break;
                    case SDL_MOUSEBUTTONDOWN:
                        do_click(x, y, e.button.button, 1);
                        break;
                    case SDL_MOUSEBUTTONUP:
                        do_click(x, y, e.button.button, 0);
                        break;
                    case SDL_KEYDOWN:
                        do_key(e.key.keysym.sym, 1);
                        break;
                    case SDL_KEYUP:
                        do_key(e.key.keysym.sym, 0);
                        break;
                    case SDL_QUIT:
                        set_val_b("running", 0);
                        set_val_b("looping", 0);
                        break;
                    }

                /* Update and render the scene. */

                now = (float) SDL_GetTicks() / 1000.f;

                while (now - then > JIFFY)
                {
                    do_timer    (JIFFY);
                    step_physics(JIFFY);

                    then += JIFFY;
                }
                
                draw_ogl(JIFFY);
                SDL_GL_SwapBuffers();
                show_fps();
            }

			ungrab();
            free_ogl();
        }
        else fprintf(stderr, "SDL_SetVideoMode: %s\n", SDL_GetError());
    }
    return 0;
}

static int do_console(void *data)
{
    char buf[256];
    SDL_Event e;

    /* Loop on the input. */

    printf("%s Console\n", TITLE);
    printf("> ");

    while (fgets(buf, 256, stdin))
    {
        /* Package each line as an SDL event. */

        e.type = SDL_USEREVENT;

        if ((e.user.data1 = malloc(strlen(buf) + 1)))
            strcpy(e.user.data1, buf);

        /* Send the event to the display thread and await its processing. */

        SDL_PushEvent(&e);
        SDL_SemWait(sem);

        printf("> ");
    }
    return 0;
}

int main(int argc, char *argv[])
{
    /* Initialize the Lua interpreter and libraries. */

    if ((lua = lua_open()))
    {
        int argi;

        luaopen_base(lua);
        luaopen_math(lua);
        luaopen_table(lua);
        luaopen_string(lua);
        luaopen_io(lua);

        lua_function(lua, "add_object", lua_add_object);
        lua_function(lua, "get_object", lua_get_object);
        lua_function(lua, "put_object", lua_put_object);

        /* Evaluate any Lua code given on the command line. */

        for (argi = 1; argi < argc; ++argi)
            eval(argv[argi]);

        init_lua();
    }

    /* Initialize SDL and launch the console and video threads. */

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_NOPARACHUTE) == 0)
    {
        sem = SDL_CreateSemaphore(0);

#ifndef _WIN32
        SDL_CreateThread(do_console, NULL);
#endif
        do_video(argc, argv);

        SDL_DestroySemaphore(sem);
        SDL_Quit();
    }
    else fprintf(stderr, "SDL_Init: %s\n", SDL_GetError());

    return 0;
}
