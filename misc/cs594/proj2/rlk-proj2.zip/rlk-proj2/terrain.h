#ifndef _TERRAIN_H
#define _TERRAIN_H

#include "main.h"

/*---------------------------------------------------------------------------*/

#define TERRAIN_W  128
#define TERRAIN_H  128
#define TERRAIN_D   32
#define TERRAIN_0   -8

/*---------------------------------------------------------------------------*/

GLuint init_texture(const char *);

int  get_terrain_w(void);
int  get_terrain_h(void);
void get_terrain_v(float[3], int, int);
void get_terrain_n(float[3], int, int);

void init_terrain(void);
void draw_terrain(int, float, GLuint);
void free_terrain(void);

void draw_terrain_clamp(void);

/*---------------------------------------------------------------------------*/

#endif
