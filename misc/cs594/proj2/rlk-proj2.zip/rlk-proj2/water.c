#include "terrain.h"
#include "physics.h"
#include "main.h"

/*---------------------------------------------------------------------------*/

const float water_x0 = -25.0f;
const float water_x1 =  40.0f;
const float water_z0 = -40.0f;
const float water_z1 =  25.0f;

static GLuint water_above_prog;
static GLuint water_below_prog;

static GLuint water_n_prog;
static GLuint water_p_prog;

GLuint water_n_map;

static GLuint water_p_map[3];
static GLuint scene_v_map;

static GLuint water_n_fbo;
static GLuint water_p_fbo[3];
static GLuint scene_v_fbo;

static int t2 = 2;
static int t1 = 1;
static int t0 = 0;

/*---------------------------------------------------------------------------*/

static void init_fbo(GLuint *fbo, GLuint *color, int w, int h, float c)
{
    /* Generate frame buffer and render buffer objects. */

    glGenFramebuffersEXT(1, fbo);
    glGenTextures       (1, color);

    /* Initialize the value render target. */

    glBindTexture(GL_TEXTURE_2D, *color);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0,
                 GL_RGBA, GL_INT, NULL);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

    /* Initialize the frame buffer object. */

    glBindFramebufferEXT     (GL_FRAMEBUFFER_EXT, *fbo);
    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT,
                              GL_COLOR_ATTACHMENT0_EXT,
                              GL_TEXTURE_2D, *color, 0);

    /* Set its default value. */

    glClearColor(c, c, c, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);
}

static void free_fbo(GLuint *fbo, GLuint *color)
{
    glDeleteFramebuffersEXT(1, fbo);
    glDeleteTextures       (1, color);
}

/*---------------------------------------------------------------------------*/

static void draw_water_P(GLdouble n, GLdouble f)
{
    int w = get_val_i("water_w");
    int h = get_val_i("water_h");

    /* Project the plane of the water to fill the render buffer. */

    glMatrixMode(GL_PROJECTION);
    {
        glPushMatrix();
        glLoadIdentity();
        glOrtho(water_x0, water_x1, -water_z1, -water_z0, n, f);
    }
    glMatrixMode(GL_MODELVIEW);
    {
        glPushMatrix();
        glLoadIdentity();
        glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
    }
    glViewport(0, 0, w, h);
}

static void undo_water_P(void)
{
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}

static void draw_water_k(void)
{
    glBegin(GL_POLYGON);
    {
        glTexCoord2i(0, 0); glVertex3f(water_x0, 0.0f, water_z1);
        glTexCoord2i(1, 0); glVertex3f(water_x1, 0.0f, water_z1);
        glTexCoord2i(1, 1); glVertex3f(water_x1, 0.0f, water_z0);
        glTexCoord2i(0, 1); glVertex3f(water_x0, 0.0f, water_z0);
    }
    glEnd();
}

static void draw_water_n(void)
{
    /* Determine the normal of each point of the water using finite         */
    /* differences of position.                                             */

    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, water_n_fbo);

    /* Set up the water texture state. */

    glActiveTextureARB(GL_TEXTURE0_ARB);
    glBindTexture(GL_TEXTURE_2D, water_p_map[t2]);

    /* Set up the shader and uniforms. */

    glUseProgramObjectARB(water_n_prog);

    glUniform1iARB(glGetUniformLocationARB(water_n_prog, "water_p"), 0);
    glUniform2fARB(glGetUniformLocationARB(water_n_prog, "size"),
                                           1.0f / get_val_i("water_w"),
                                           1.0f / get_val_i("water_h"));

    /* Draw the water plane. */

    draw_water_P(-1.0, +1.0);
    draw_water_k();
    undo_water_P();

    /* Disable all state. */

    glUseProgramObjectARB(0);

    glActiveTextureARB(GL_TEXTURE0_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);
}

static void draw_water_p(float dt)
{
    /* Determine the position of each point of the water using a Verlet     */
    /* integrated wave simulation influenced by the object map and clamped  */
    /* by the water extent map.                                             */

    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, water_p_fbo[t2]);

    /* Set up the water texture state. */


    glActiveTextureARB(GL_TEXTURE2_ARB);
    glBindTexture(GL_TEXTURE_2D, scene_v_map);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    glBindTexture(GL_TEXTURE_2D, water_p_map[t1]);

    glActiveTextureARB(GL_TEXTURE0_ARB);
    glBindTexture(GL_TEXTURE_2D, water_p_map[t0]);

    /* Set up the shader and uniforms. */

    glUseProgramObjectARB(water_p_prog);

    glUniform1iARB(glGetUniformLocationARB(water_p_prog, "water_p0"), 0);
    glUniform1iARB(glGetUniformLocationARB(water_p_prog, "water_p1"), 1);
    glUniform1iARB(glGetUniformLocationARB(water_p_prog, "scene_v"),  2);
    glUniform1fARB(glGetUniformLocationARB(water_p_prog, "time"),   dt);
    glUniform2fARB(glGetUniformLocationARB(water_p_prog, "size"),
                                           1.0f / get_val_i("water_w"),
                                           1.0f / get_val_i("water_h"));

    /* Draw the water plane. */

    draw_water_P(-1.0, +1.0);
    draw_water_k();
    undo_water_P();

    /* Disable all state. */

    glUseProgramObjectARB(0);

    glActiveTextureARB(GL_TEXTURE2_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);

    glActiveTextureARB(GL_TEXTURE0_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);
}

static void draw_scene_v(void)
{
    float k = 1.0;

    /* Find the objects' influence on the water by rendering the vertical    */
    /* velocities of all objects intersecting the water plane.               */

    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, scene_v_fbo);

    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(1.0f, 1.0f, 1.0f);

    draw_water_P(-k, +k);
    draw_objects_velocity();
    undo_water_P();
}

/*---------------------------------------------------------------------------*/

void init_water(void)
{
    int w = get_val_i("water_w");
    int h = get_val_i("water_h");

    water_above_prog = make_program("data/water.vert","data/water_above.frag");
    water_below_prog = make_program("data/water.vert","data/water_below.frag");

    water_n_prog = make_program("data/water_k.vert", "data/water_n.frag");
    water_p_prog = make_program("data/water_k.vert", "data/water_p.frag");

    init_fbo(&water_n_fbo,    &water_n_map,    w, h, 0.5f);
    init_fbo(&water_p_fbo[0], &water_p_map[0], w, h, 0.0f);
    init_fbo(&water_p_fbo[1], &water_p_map[1], w, h, 0.0f);
    init_fbo(&water_p_fbo[2], &water_p_map[2], w, h, 0.0f);
    init_fbo(&scene_v_fbo,    &scene_v_map,    w, h, 0.5f);
}

void step_water(float dt)
{
    /* Do the water simulation. */

    glPushAttrib(GL_COLOR_BUFFER_BIT | GL_VIEWPORT_BIT |
                 GL_DEPTH_BUFFER_BIT | GL_ENABLE_BIT);
    {
        glDepthMask(GL_FALSE);

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_LIGHTING);
        glDisable(GL_BLEND);

        /* Render each of the intermediate buffers. */

        draw_scene_v();
        draw_water_p(dt);
        draw_water_n();

        /* Ping-pong the FBOs. */

        t0 = (t0 + 1) % 3;
        t1 = (t1 + 1) % 3;
        t2 = (t2 + 1) % 3;
    }
    glPopAttrib();
}

void draw_plane(int n)
{
    /* Draw the water plane. */

    glPushAttrib(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT | GL_ENABLE_BIT);
    {
        glEnable(GL_CULL_FACE);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDepthMask(GL_FALSE);

        glBegin(GL_POLYGON);
        {
            float y = 0.0f;

            if (n > 0)
            {
                glNormal3f(0.0f, 1.0f, 0.0f);

                glTexCoord2i(0, 0); glVertex3f(water_x0, y, water_z1);
                glTexCoord2i(1, 0); glVertex3f(water_x1, y, water_z1);
                glTexCoord2i(1, 1); glVertex3f(water_x1, y, water_z0);
                glTexCoord2i(0, 1); glVertex3f(water_x0, y, water_z0);
            }
            else
            {
                glNormal3f(0.0f, -1.0f, 0.0f);

                glTexCoord2i(1, 0); glVertex3f(water_x1, y, water_z1);
                glTexCoord2i(0, 0); glVertex3f(water_x0, y, water_z1);
                glTexCoord2i(0, 1); glVertex3f(water_x0, y, water_z0);
                glTexCoord2i(1, 1); glVertex3f(water_x1, y, water_z0);
            }
        }
        glEnd();
    }
    glPopAttrib();
}

void draw_water(float dt, GLuint reflect_map, GLuint refract_map)
{
    /* Set up the water texture state. */

    glActiveTextureARB(GL_TEXTURE1_ARB);
    glBindTexture(GL_TEXTURE_2D, water_n_map);

    glActiveTextureARB(GL_TEXTURE2_ARB);
    glBindTexture(GL_TEXTURE_2D, reflect_map);

    glActiveTextureARB(GL_TEXTURE3_ARB);
    glBindTexture(GL_TEXTURE_2D, refract_map);

    glActiveTextureARB(GL_TEXTURE0_ARB);

    if (get_val_f("camera_y") >= 0)
    {
        /* Draw the water from above. */

        GLuint prog = water_above_prog;

        glUseProgramObjectARB(prog);

        glUniform1iARB(glGetUniformLocationARB(prog, "water_n"),        1);
        glUniform1iARB(glGetUniformLocationARB(prog, "reflection_map"), 2);
        glUniform1iARB(glGetUniformLocationARB(prog, "refraction_map"), 3);

        draw_plane(+1);
    }
    else
    {
        /* Draw the water from below. */

        GLuint prog = water_below_prog;

        glUseProgramObjectARB(prog);

        glUniform1iARB(glGetUniformLocationARB(prog, "water_n"),        1);
        glUniform1iARB(glGetUniformLocationARB(prog, "reflection_map"), 3);
        glUniform1iARB(glGetUniformLocationARB(prog, "refraction_map"), 2);

        draw_plane(-1);
    }

    /* Disable all state. */

    glUseProgramObjectARB(0);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);

    glActiveTextureARB(GL_TEXTURE2_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);

    glActiveTextureARB(GL_TEXTURE3_ARB);
    glBindTexture(GL_TEXTURE_2D, 0);

    glActiveTextureARB(GL_TEXTURE0_ARB);
}

void free_water(void)
{
    free_fbo(&water_n_fbo,    &water_n_map);
    free_fbo(&water_p_fbo[0], &water_p_map[0]);
    free_fbo(&water_p_fbo[1], &water_p_map[1]);
    free_fbo(&water_p_fbo[2], &water_p_map[2]);
    free_fbo(&scene_v_fbo,    &scene_v_map);

    if (water_above_prog) glDeleteObjectARB(water_above_prog);
    if (water_below_prog) glDeleteObjectARB(water_below_prog);
}

/*---------------------------------------------------------------------------*/
