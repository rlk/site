#include <stdlib.h>

#include "main.h"
#include "obj.h"

/*---------------------------------------------------------------------------*/

#define NRES 128

static int    sky_dome;
static GLuint sky_prog;

static GLuint cloud_prog;

/*---------------------------------------------------------------------------*/

static int noise_init = 0;
static GLuint noise_map;

static GLubyte noise[NRES][NRES][NRES][4];

#define interp(a, b, t) ((a) + (t * t * (3.0f - 2.0f * t)) * ((b) - (a)))

static void fill_noise(int l, int n)
{
    int i;
    int j;
    int k;

    float i00, i10, j00;
    float i01, i11, j11;

    float kk;

    /* Seed the volume with random values. */

    for (i = 0; i < NRES; i += n)
        for (j = 0; j < NRES; j += n)
            for (k = 0; k < NRES; k += n)
                noise[i][j][k][l] = rand() % 256;

    /* Interpolate these values throughout the volume. */

    for (i = 0; i < NRES; ++i)
    {
        int i0 = (i  / n) * n;
        int i1 = (i0 + n) % NRES;

        float it = (float) (i - i0) / n;

        for (j = 0; j < NRES; ++j)
        {
            int j0 = (j /  n) * n;
            int j1 = (j0 + n) % NRES;

            float jt = (float) (j - j0) / n;

            for (k = 0; k < NRES; ++k)
            {
                int k0 = (k  / n) * n;
                int k1 = (k0 + n) % NRES;

                float kt = (float) (k - k0) / n;

                i00 = interp(noise[i0][j0][k0][l], noise[i1][j0][k0][l], it);
                i10 = interp(noise[i0][j1][k0][l], noise[i1][j1][k0][l], it);
                i01 = interp(noise[i0][j0][k1][l], noise[i1][j0][k1][l], it);
                i11 = interp(noise[i0][j1][k1][l], noise[i1][j1][k1][l], it);

                j00 = interp(i00, i10, jt);
                j11 = interp(i01, i11, jt);
                kk  = interp(j00, j11, kt);

                noise[i][j][k][l] = (GLubyte) kk;
            }
        }
    }
}

void init_sky(void)
{
    /* Load the shaders and image maps. */

    sky_dome = obj_add_file("data/geodesic_dome.obj");

    sky_prog   = make_program("data/sky.vert",   "data/sky.frag");
    cloud_prog = make_program("data/cloud.vert", "data/cloud.frag");

    /* Initialize the noise buffer. */

    if (noise_init == 0)
    {
        fill_noise(0, 32);
        fill_noise(1, 16);
        fill_noise(2,  8);
        fill_noise(3,  4);

        noise_init = 1;
    }

    /* Generate a noise texture. */

    glGenTextures(1, &noise_map);
    glBindTexture(GL_TEXTURE_3D, noise_map);

	/*
    gluBuild3DMipmaps(GL_TEXTURE_3D, GL_RGBA, NRES, NRES, NRES,
                      GL_RGBA, GL_UNSIGNED_BYTE, noise);
					  */
    glTexImage3DEXT(GL_TEXTURE_3D, 0, GL_RGBA, NRES, NRES, NRES, 0,
                    GL_RGBA, GL_UNSIGNED_BYTE, noise);

    glTexParameteri(GL_TEXTURE_3D,
                    GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_3D,
                    GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	/*
    glTexParameteri(GL_TEXTURE_3D,
                    GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	*/

    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_REPEAT);
}

void draw_sky(void)
{
    float f = get_val_f("camera_far");

    /* Draw the sky dome. */

    glUseProgramObjectARB(sky_prog);

    glUniform3fARB(glGetUniformLocationARB(sky_prog, "horizon"),
                                           get_val_f("horizon_r"),
                                           get_val_f("horizon_g"),
                                           get_val_f("horizon_b"));
    glUniform3fARB(glGetUniformLocationARB(sky_prog, "zenith"),
                                           get_val_f("zenith_r"),
                                           get_val_f("zenith_g"),
                                           get_val_f("zenith_b"));
    glPushAttrib(GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    {
        glDisable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);

        glScalef(f, f, f);
        obj_draw_file(sky_dome);
    }
    glPopMatrix();
    glPopAttrib();

    /* Draw the cloud layer. */

    glUseProgramObjectARB(cloud_prog);

    glUniform1iARB(glGetUniformLocationARB(cloud_prog, "noise_map"), 0);
    glUniform1fARB(glGetUniformLocationARB(cloud_prog, "time"), get_time());
    glUniform3fARB(glGetUniformLocationARB(cloud_prog, "wind"),
                                             get_val_f("wind_x"),
                                             get_val_f("wind_y"),
                                             get_val_f("wind_z"));

    glPushAttrib(GL_COLOR_BUFFER_BIT | GL_ENABLE_BIT);
    {
        glEnable(GL_TEXTURE_3D);
        glEnable(GL_BLEND);
        glBindTexture(GL_TEXTURE_3D, noise_map);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);

        glBegin(GL_POLYGON);
        {
            float h = 32.0f;

            glTexCoord3f(0.0f, 0.0f, 0.0f); glVertex3f(-f, h, +f);
            glTexCoord3f(1.0f, 0.0f, 0.0f); glVertex3f(+f, h, +f);
            glTexCoord3f(1.0f, 1.0f, 0.0f); glVertex3f(+f, h, -f);
            glTexCoord3f(0.0f, 1.0f, 0.0f); glVertex3f(-f, h, -f);
        }
        glEnd();
    }
    glPopAttrib();

    glUseProgramObjectARB(0);
}

void free_sky(void)
{
    glDeleteObjectARB(sky_prog);
    obj_del_file(sky_dome);
}

/*---------------------------------------------------------------------------*/
