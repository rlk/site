#include "opengl.hpp"
#include "light.hpp"

//-----------------------------------------------------------------------------

void light::draw()
{
    GLfloat P[4] = { 0.0, 0.0, 0.0, 1.0 };

    glPushMatrix();
    {
        mult_M();

        glLightfv(GL_LIGHT0, GL_POSITION, P);
    }
    glPopMatrix();
}

//-----------------------------------------------------------------------------
