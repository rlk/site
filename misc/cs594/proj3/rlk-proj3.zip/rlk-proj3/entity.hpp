#ifndef ENTITY_HPP
#define ENTITY_HPP

#include "obj.h"

//-----------------------------------------------------------------------------

class entity
{
protected:

    int file;

    float p[3];
    float r[3];

public:

    entity(float x=0, float y=0, float z=0, int f=-1);

    void move(float, float, float);
    void turn(float, float, float);

    void mult_M();
    void mult_V();

    virtual void draw();

    virtual ~entity();
};

//-----------------------------------------------------------------------------

#endif
