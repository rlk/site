#ifndef DEMO_HPP
#define DEMO_HPP

#include "opengl.hpp"
#include "camera.hpp"
#include "light.hpp"
#include "plane.hpp"
#include "mesh.hpp"
#include "gui.hpp"
#include "app.hpp"

#include "varrier_combiner.h"
#include "tracker.h"

//-----------------------------------------------------------------------------

class demo : public app
{
    conf *_conf;

    light  L;
    camera C;
    plane  P;
    mesh   M;
    gui    G;

    int mouse_x;
    int mouse_y;
    int mouse_b;
    int mouse_d;

    int motion[3];

    bool run;
    bool show_gui;
    bool show_ribbon;
    bool show_vertex;
    bool show_spring;
    bool show_floor;

    vc_display V;

    void draw();

public:

    demo(conf *, data *);

    void timer(float);
    void point(int, int);
    void click(int, bool);
    void keybd(int, bool);
    void paint();
};

//-----------------------------------------------------------------------------

#endif
