#include <SDL.h>

#include "opengl.hpp"
#include "demo.hpp"

//-----------------------------------------------------------------------------

demo::demo(conf *c, data *d) : app(c, d), _conf(c),
                               L(c), C(c), P(d), M(c, d), G(c)
{
    // Initialize the demo state.

    motion[0] = 0;
    motion[1] = 0;
    motion[2] = 0;

    run         = false;
    show_gui    = false;
    show_ribbon = true;
    show_vertex = false;
    show_spring = false;
    show_floor  = true;

    // Initialize the vc_display structure.

    V.quality = 0.4f;

    V.viewport_x = 0;
    V.viewport_y = 0;

    V.viewport_w = c->get_i("window_w");
    V.viewport_h = c->get_i("window_h");

    V.screen_BL[0] = c->get_f("screen_BL_x");
    V.screen_BL[1] = c->get_f("screen_BL_y");
    V.screen_BL[2] = c->get_f("screen_BL_z");

    V.screen_TL[0] = c->get_f("screen_TL_x");
    V.screen_TL[1] = c->get_f("screen_TL_y");
    V.screen_TL[2] = c->get_f("screen_TL_z");

    V.screen_BR[0] = c->get_f("screen_BR_x");
    V.screen_BR[1] = c->get_f("screen_BR_y");
    V.screen_BR[2] = c->get_f("screen_BR_z");

    V.pitch = c->get_f("pitch");
    V.angle = c->get_f("angle");
    V.thick = c->get_f("thick");
    V.shift = c->get_f("shift");
    V.cycle = c->get_f("cycle");

    // Initialize the tracker.

    tracker_init(TRACKER_KEY, CONTROL_KEY);

    if (c->get_i("stereo_mode") == 1)
        vc_init(c->get_i("window_w"),
                c->get_i("window_h"));
}

//-----------------------------------------------------------------------------

void demo::timer(float dt)
{
    float k = _conf->get_f("camera_move_rate") * dt;

    C.move(float(motion[0]) * k,
           float(motion[1]) * k,
           float(motion[2]) * k);

    M.step(run ? dt : 0.0f);

    app::timer(dt);
}

void demo::point(int x, int y)
{
    if (_conf->get_i("stereo_mode") == 2) x = x * 2;

    if (!show_gui || !G.point(x, y))
    {
        float k = _conf->get_f("camera_turn_rate");

        if (mouse_d && mouse_b == 1)
            C.turn(float(mouse_y - y) * k,
                   float(mouse_x - x) * k, 0.0);

        mouse_x = x;
        mouse_y = y;

        app::point(x, y);
    }
}

void demo::click(int b, bool d)
{
    if (!show_gui || !G.click(b, d))
    {
        mouse_b = b;
        mouse_d = d;

        app::click(b, d);
    }
}

void demo::keybd(int k, bool d)
{
    int dd = d ? +1 : -1;

    if (k == _conf->get_i("move_L")) motion[0] -= dd;
    if (k == _conf->get_i("move_R")) motion[0] += dd;
    if (k == _conf->get_i("move_F")) motion[2] -= dd;
    if (k == _conf->get_i("move_B")) motion[2] += dd;

    if (d)
    {
        if (k == _conf->get_i("toggle_run"))    run         = !run;
        if (k == _conf->get_i("toggle_gui"))    show_gui    = !show_gui;
        if (k == _conf->get_i("toggle_ribbon")) show_ribbon = !show_ribbon;
        if (k == _conf->get_i("toggle_vertex")) show_vertex = !show_vertex;
        if (k == _conf->get_i("toggle_spring")) show_spring = !show_spring;
        if (k == _conf->get_i("toggle_floor"))  show_floor  = !show_floor;

        if (k == _conf->get_i("reset"))      M.init();
    }

    app::keybd(k, d);
}

//-----------------------------------------------------------------------------

void demo::draw()
{
    glClearColor(0.0f, 0.1f, 0.2f, 0.0f);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glPushMatrix();
    {
        C.draw();
        L.draw();

        if (show_floor)
            P.draw();

        glPushMatrix();
        {
            glScalef(0.25f, 0.25f, 0.25f);
            M.draw(show_ribbon, show_vertex, show_spring);
        }
        glPopMatrix();

        if (show_gui)
            G.draw();
    }
    glPopMatrix();

    app::paint();
}

void demo::paint()
{
	int w = _conf->get_i("window_w");
	int h = _conf->get_i("window_h");

    float n = _conf->get_f("camera_near");
    float f = _conf->get_f("camera_far");

    float L_eye[3];
    float R_eye[3];

    // Set the eye positions.

    if (tracker_status())
    {
        float p[3];

        tracker_position(0, p);

        L_eye[0] = p[0] - _conf->get_f("eye_dist") / 2.0f;
        L_eye[1] = p[1];
        L_eye[2] = p[2];

        R_eye[0] = p[0] + _conf->get_f("eye_dist") / 2.0f;
        R_eye[1] = p[1];
        R_eye[2] = p[2];
    }
    else
    {
        L_eye[0] = _conf->get_f("head_x") - _conf->get_f("eye_dist") / 2.0f;
        L_eye[1] = _conf->get_f("head_y");
        L_eye[2] = _conf->get_f("head_z");

        R_eye[0] = _conf->get_f("head_x") + _conf->get_f("eye_dist") / 2.0f;
        R_eye[1] = _conf->get_f("head_y");
        R_eye[2] = _conf->get_f("head_z");
    }

    // Render the scene.

    switch (_conf->get_i("stereo_mode"))
    {
    case 0:
        vc_frustum(&V, L_eye, n, f);
        draw();
        break;

    case 1:
        vc_prepare(&V, 0);
        vc_frustum(&V, L_eye, n, f);
        draw();

        vc_prepare(&V, 1);
        vc_frustum(&V, R_eye, n, f);
        draw();

        vc_combine(&V, L_eye, R_eye);
        break;

	case 2:
        glPushAttrib(GL_ENABLE_BIT);
        {
            glEnable(GL_SCISSOR_TEST);

            glViewport(0, 0, w / 2, h);
            glScissor (0, 0, w / 2, h);
            vc_frustum(&V, L_eye, n, f);
            draw();

            glViewport(w / 2, 0, w / 2, h);
            glScissor (w / 2, 0, w / 2, h);
            vc_frustum(&V, R_eye, n, f);
            draw();
        }
        glPopAttrib();
        break;
    }
}

//-----------------------------------------------------------------------------

