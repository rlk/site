#ifndef PLANE_HPP
#define PLANE_HPP

#include "entity.hpp"
#include "data.hpp"

//-----------------------------------------------------------------------------

class plane : public entity
{
public:

    plane(data *d) : entity(0, 0, 0, d->get_obj("floor.obj")) { }
};

//-----------------------------------------------------------------------------

#endif
