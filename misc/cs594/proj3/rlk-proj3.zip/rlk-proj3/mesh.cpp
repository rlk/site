#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

#include "opengl.hpp"
#include "mesh.hpp"

//-----------------------------------------------------------------------------

mesh::mesh(conf *c, data *d) : _conf(c),

                               n(c->get_i("particles_n")),

                               format((c->get_i("precision") == 32)
                                      ? GL_RGB32F_ARB
                                      : GL_RGB16F_ARB),

                               force(d->get_txt("force.vert"),
                                     d->get_txt("force.frag")),
                               total(d->get_txt("total.vert"),
                                     d->get_txt("total.frag")),

                               velocity(d->get_txt("velocity.vert"),
                                        d->get_txt("velocity.frag")),
                               position(d->get_txt("position.vert"),
                                        d->get_txt("position.frag")),

                               normal(d->get_txt("normal.vert"),
                                      d->get_txt("normal.frag")),
                               ribbon(d->get_txt("ribbon.vert"),
                                      d->get_txt("ribbon.frag")),

                               P0(format, GL_RGB, 2, n / 2),
                               P1(format, GL_RGB, 2, n / 2),
                               N0(format, GL_RGB, 2, n / 2),
                               N1(format, GL_RGB, 2, n / 2),
                               V0(format, GL_RGB, 2, n / 2),
                               V1(format, GL_RGB, 2, n / 2),
                               F0(format, GL_RGB, n, n),
                               F1(format, GL_RGB, n, n),

                               V(GL_PIXEL_PACK_BUFFER_ARB,
                                 GL_DYNAMIC_DRAW_ARB, n * 24)
{
    float kx = 0.5f;
    float ky = 2.0f / float(n);

    parity = false;

    // Configure the shaders.

    force.bind();
    force.uniform("k", kx, ky);

    total.bind();
    total.uniform("n", float(n));

    position.bind();
    position.uniform("n", float(n));
    position.uniform("k", kx, ky);

    velocity.bind();
    velocity.uniform("n", float(n));
    velocity.uniform("k", kx, ky);

    normal.bind();
    normal.uniform("n", float(n));
    normal.uniform("k", kx, ky);

    glUseProgramObjectARB(0);

    // Load the initial file.

    load(_conf->get_s("knot_file"));

    GL_CHECK();
}

//-----------------------------------------------------------------------------

struct point
{
    float x;
    float y;
    float z;
};

void mesh::load(std::string filename)
{
    std::ifstream      fin(filename.c_str());
    std::vector<point> src;
    std::vector<point> dst;

    if (fin)
    {
        point p;
        int   i;

        float dy = 0;
        float dd = 0;

        // Read all points from the named file.

        while (fin >> p.x >> p.y >> p.z)
        {
			if (dy > p.y)
				dy = p.y;

            src.push_back(p);
        }

        // Measure the total length of the loop and set the spring length.

        for (i = 0; i < int(src.size()); ++i)
        {
            point p = src[(i)];
            point q = src[(i + 1) % src.size()];

            dd += sqrt((q.x - p.x) * (q.x - p.x) +
                       (q.y - p.y) * (q.y - p.y) +
                       (q.z - p.z) * (q.z - p.z));
        }

        dd = 2.0f * dd / n;

        _conf->set_f("spring_length", dd);

        // Expand the loaded points to N vertices.

        for (i = 0; i < n; i += 2)
        {
            float j = (src.size()) * float(i) / float(n);

            int  j0 = int(floor(j)) % int(src.size());
            int  j1 = int( ceil(j)) % int(src.size());

            float k = j - j0;

            // Vertex 0 is the interpolation of the two nearest points.

            p.x = src[j0].x * (1 - k) + src[j1].x * k;
            p.y = src[j0].y * (1 - k) + src[j1].y * k - dy;
            p.z = src[j0].z * (1 - k) + src[j1].z * k - dd / 2.0f;

            dst.push_back(p);

            // Vertex 1 is vertex 0 offset along the Z axis.

            p.z = src[j0].z * (1 - k) + src[j1].z * k + dd / 2.0f;

            dst.push_back(p);
        }

        // Copy the loaded vertices to the position buffers.

        P0.bind_color(GL_TEXTURE0);
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 2, n / 2,
                        GL_RGB, GL_FLOAT, &dst.front());

        P1.bind_color(GL_TEXTURE0);
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 2, n / 2,
                        GL_RGB, GL_FLOAT, &dst.front());
    }
}

void mesh::init()
{
    GLint o[1], v[4];

    // Clear all buffers.

    get_framebuffer(o, v);
    {
        P0.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
        P1.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
        N0.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
        N1.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
        V0.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
        V1.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
        F0.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
        F1.bind_frame(); glClear(GL_COLOR_BUFFER_BIT);
    }
    set_framebuffer(o, v);

    // Reload the mesh definition.

    load(_conf->get_s("knot_file"));
}

//-----------------------------------------------------------------------------

static void rect(float k)
{
    // Set up a one-to-one transformation.

    glMatrixMode(GL_PROJECTION);
    {
        glPushMatrix();
        glLoadIdentity();
        glOrtho(0.0, 1.0, 0.0, 1.0, 0.0, 1.0);
    }
    glMatrixMode(GL_MODELVIEW);
    {
        glPushMatrix();
        glLoadIdentity();
    }

    // Draw a screen-filling polygon.

    glPushAttrib(GL_ENABLE_BIT);
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);

        glBegin(GL_POLYGON);
        {
            glVertex2f(0, 0);
            glVertex2f(1, 0);
            glVertex2f(1, k);
            glVertex2f(0, k);
        }
        glEnd();
    }
    glPopAttrib();

    // Revert the transformation.

    glMatrixMode(GL_PROJECTION);
    {
        glPopMatrix();
    }
    glMatrixMode(GL_MODELVIEW);
    {
        glPopMatrix();
    }
    GL_CHECK();
}

void mesh::phys(fbo& p0, fbo& p1,
                fbo& n0, fbo& n1,
                fbo& v0, fbo& v1, float dt)
{
    fbo *F = &F0;
    fbo *G = &F1;
    fbo *T;

    // Compute the particle-to-particle forces.

    p0.bind_color(GL_TEXTURE0);
    F0.bind_frame();

    force.bind();
    force.uniform("position", 0);
    force.uniform("force_const1",  _conf->get_f("force_const1"));
    force.uniform("force_const2",  _conf->get_f("force_const2"));
    force.uniform("force_power1",  _conf->get_f("force_power1"));
    force.uniform("force_power2",  _conf->get_f("force_power2"));

    rect(1.0f);

    // Compute the force totals.

    total.bind();
    total.uniform("force", 0);

    for (int i = 1; i < n; i *= 2)
    {
        F->bind_color(GL_TEXTURE0);
        G->bind_frame();

        rect(0.5f / i);

        T = F;
        F = G;
        G = T;
    }

    // Compute the velocities.

    v0.bind_color(GL_TEXTURE0);
    p0.bind_color(GL_TEXTURE1);
    F->bind_color(GL_TEXTURE2);
    v1.bind_frame();

    velocity.bind();
    velocity.uniform("dt", dt);
    velocity.uniform("motion_dampen", _conf->get_f("motion_dampen"));
    velocity.uniform("spring_factor", _conf->get_f("spring_factor"));
    velocity.uniform("spring_length", _conf->get_f("spring_length"));
    velocity.uniform("spring_dampen", _conf->get_f("spring_dampen"));

    velocity.uniform("velocity", 0);
    velocity.uniform("position", 1);
    velocity.uniform("force",    2);

    rect(1.0f);

    // Compute the positions.

    p0.bind_color(GL_TEXTURE0);
    v1.bind_color(GL_TEXTURE1);
    p1.bind_frame();

    position.bind();
    position.uniform("dt", dt);
    position.uniform("position", 0);
    position.uniform("velocity", 1);

    rect(1.0f);

    // Compute the normals.

    p1.bind_color(GL_TEXTURE0);
    n1.bind_frame();

    normal.bind();
    normal.uniform("position", 0);

    rect(1.0f);
}

void mesh::step(float dt)
{
    GLint o[1], v[4];
    parity = !parity;

    get_framebuffer(o, v);
    {
        // Step the physical simulation.

        if (parity)
            phys(P0, P1, N0, N1, V0, V1, dt);
        else
            phys(P1, P0, N1, N0, V1, V0, dt);

        glUseProgramObjectARB(0);

        // Copy the position buffer to the vertex array.

        V.bind(GL_PIXEL_PACK_BUFFER_ARB);

        if (parity)
            P1.bind_frame();
        else
            P0.bind_frame();

        glReadPixels(0, 0, 2, n / 2, GL_RGB, GL_FLOAT, (GLvoid *) (0));

        // Copy the normal buffer to the normal array.

        if (parity)
            N1.bind_frame();
        else
            N0.bind_frame();

        glReadPixels(0, 0, 2, n / 2, GL_RGB, GL_FLOAT, (GLvoid *) (n * 12));

        // Unbind the buffers.

        glBindBufferARB(GL_PIXEL_PACK_BUFFER_ARB, 0);
    }
    set_framebuffer(o, v);

    GL_CHECK();
}

//-----------------------------------------------------------------------------

void mesh::draw(bool show_ribbon,
                bool show_vertex,
                bool show_spring)
{
    glPushMatrix();
    glPushAttrib(GL_ENABLE_BIT);
    {
        mult_M();

        // Bind the vertex buffer objects.

        V.bind(GL_ARRAY_BUFFER_ARB);

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_NORMAL_ARRAY);

        glVertexPointer(3, GL_FLOAT, 0, (GLvoid *) (0));
        glNormalPointer(   GL_FLOAT, 0, (GLvoid *) (n * 12));

        if (show_ribbon)
        {
            float Ks[4] = { 0.5f, 0.5f, 0.5f, 1.0f };
            float Kd[4] = { 0.3f, 0.5f, 0.5f, 1.0f };

            // Set the material properties.

            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  Kd);
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  Kd);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, Ks);

            ribbon.bind();

            // Render the ribbon.

            glDrawArrays(GL_QUAD_STRIP, 0, n);

            // Fill the gap in the ribbon.

            glBegin(GL_QUAD_STRIP);
            {
                glArrayElement(n - 2);
                glArrayElement(n - 1);
                glArrayElement(0);
                glArrayElement(1);
            }
            glEnd();
        }

        if (show_vertex)
        {
            glUseProgramObjectARB(0);
            glDisable(GL_LIGHTING);
            glPointSize(4.0);

            // Render the vertices.

            glColor4f(1.0f, 1.0f, 0.0f, 0.8f);
            glDrawArrays(GL_POINTS, 0, n);
        }

        if (show_spring)
        {
            glUseProgramObjectARB(0);
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

            glPointSize(4.0);

            // Render the springs.

            glColor4f(0.0f, 1.0f, 0.0f, 0.5f);

            glPushAttrib(GL_POLYGON_BIT);
            {
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

                glDrawArrays(GL_QUAD_STRIP, 0, n);

                glBegin(GL_QUAD_STRIP);
                {
                    glArrayElement(n - 2);
                    glArrayElement(n - 1);
                    glArrayElement(0);
                    glArrayElement(1);
                }
                glEnd();
            }
            glPopAttrib();
        }

        // Revert all state.

        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_NORMAL_ARRAY);

        glUseProgramObjectARB(0);
        glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
    }
    glPopAttrib();
    glPopMatrix();

    GL_CHECK();
}

//-----------------------------------------------------------------------------
