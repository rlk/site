#ifndef GUI_HPP
#define GUI_HPP

#include <string>

#include "conf.hpp"

//-----------------------------------------------------------------------------

class value
{
    conf *_conf;

    std::string _key;

    float _len;
    float _pos;
    float _max;

public:
    value(conf *c, std::string k, float p, float m) :
        _conf(c), _key(k), _len(10), _pos(p), _max(m) { }

    bool test(float, float);
    void drag(float);
    void draw();
};

//-----------------------------------------------------------------------------

class gui
{
    conf *_conf;

    int   w;
    int   h;
    float rows;
    float cols;
    
    bool last_d;
    int  last_b;
    int  last_x;
    int  last_y;

    value motion_dampen;
    value spring_length;
    value spring_factor;
    value spring_dampen;
    value force_const1;
    value force_const2;
    value force_power1;
    value force_power2;

    value *grab;

public:

    gui(conf *);

    bool point(int, int);
    bool click(int, bool);

    void draw();
};

//-----------------------------------------------------------------------------

#endif
