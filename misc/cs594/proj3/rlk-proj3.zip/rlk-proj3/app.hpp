#ifndef APP_HPP
#define APP_HPP

#include "conf.hpp"
#include "data.hpp"

//-----------------------------------------------------------------------------

class app
{
protected:

    conf *_conf;
    data *_data;

public:

    app(conf *c, data *d) : _conf(c), _data(d) { }

    virtual void timer(float);
    virtual void point(int, int);
    virtual void click(int, bool);
    virtual void keybd(int, bool);
    virtual void paint();

    virtual ~app();
};

//-----------------------------------------------------------------------------

#endif
