#ifndef MESH_HPP
#define MESH_HPP

#include "opengl.hpp"
#include "entity.hpp"
#include "conf.hpp"
#include "data.hpp"

//-----------------------------------------------------------------------------

class mesh : public entity
{
    conf *_conf;

    bool parity;
    int  n;
    int  format;

    shader force;
    shader total;
    shader velocity;
    shader position;
    shader normal;
    shader ribbon;

    fbo P0, P1;
    fbo N0, N1;
    fbo V0, V1;
    fbo F0, F1;

    vbo V;

    void phys(fbo&, fbo&, fbo&, fbo&, fbo&, fbo&, float);
    void load(std::string);

public:

    mesh(conf *, data *);

    void init();
    void step(float);
    void draw(bool, bool, bool);
};

//-----------------------------------------------------------------------------

#endif
