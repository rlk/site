#ifndef LIGHT_HPP
#define LIGHT_HPP

#include "entity.hpp"
#include "conf.hpp"

//-----------------------------------------------------------------------------

class light : public entity
{
public:

    light(conf *c) : entity(c->get_f("light_x"),
                            c->get_f("light_y"),
                            c->get_f("light_z"), -1) { }
    void draw();
};

//-----------------------------------------------------------------------------

#endif
