#!/bin/sh

cp $2 $1
