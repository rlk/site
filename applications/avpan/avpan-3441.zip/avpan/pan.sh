#!/bin/sh

/Applications/Hugin/HuginTools/nona -o out -m TIFF_m farhorizons2.pto dummy.jpg $2 $3 $4 $5 $6 $7
/opt/local/bin/enblend --no-optimize --fine-mask -o $1 out0001.tif out0005.tif out0002.tif out0003.tif out0004.tif out0006.tif
