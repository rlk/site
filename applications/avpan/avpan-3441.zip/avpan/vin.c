// Copyright (c) 2012 Robert Kooima
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.

#include <string.h>
#include <stdbool.h>

#include <libswscale/swscale.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>

#include "err.h"
#include "vin.h"

//------------------------------------------------------------------------------

struct vin
{
    AVFormatContext   *format;
    AVCodecContext    *codec;
    AVFrame           *yuv;
    AVFrame           *rgb;
    struct SwsContext *scale;
    int                index;
};

//------------------------------------------------------------------------------

// Initialize the format context in an input video.

static bool vin_format(const char *name, vin *in)
{
    if (avformat_open_input(&in->format, name, NULL, NULL) >= 0)
    {
        if (avformat_find_stream_info(in->format, NULL) >= 0)
        {
            return true;
        }
        else apperr("Failed to find stream info");
    }
    else apperr("Failed to open %s", name);

    return false;
}

// Initialize the codec context for the best stream in an input video.

static bool vin_codec(vin *in)
{
    AVCodec *cd;

    int i = av_find_best_stream(in->format, AVMEDIA_TYPE_VIDEO, -1, -1, &cd, 0);

    if (i >= 0)
    {
        in->codec = in->format->streams[i]->codec;
        in->index = i;

        if (avcodec_open2(in->codec, cd, NULL) >= 0)
        {
            return true;
        }
        else apperr("Failed to open video decoder");
    }
    else apperr("Failed to find a video stream");

    return false;
}

//------------------------------------------------------------------------------

// Allocate and initialize an input video. Open the named video file and
// prepare it for decoding.

vin *vin_open(const char *name)
{
    vin *in;

    av_register_all();
    avcodec_register_all();

    if ((in = (vin *) calloc(1, sizeof (vin))))
    {
        if (vin_format(name, in))
        {
            if (vin_codec(in))
            {
                in->yuv = avcodec_alloc_frame();
                in->rgb = avcodec_alloc_frame();
                in->scale = sws_getContext(in->codec->width,
                                           in->codec->height,
                                           in->codec->pix_fmt,
                                           in->codec->width,
                                           in->codec->height,
                                           PIX_FMT_RGB24,
                                           SWS_BICUBIC,
                                           NULL, NULL, NULL);
                return in;
            }
        }
        free(in);
    }
    else apperr("Failed to allocate vin");

    return NULL;
}

// Release all resources held by the given input video.

void vin_free(vin *in)
{
    if (in)
    {
        if (in->rgb)
            av_free(in->rgb);
        if (in->yuv)
            av_free(in->yuv);
        if (in->scale)
            sws_freeContext(in->scale);
        if (in->codec)
            avcodec_close(in->codec);
        if (in->format)
            avformat_close_input(&in->format);

        free(in);
    }
}

//------------------------------------------------------------------------------

// Return the input video width.

int vin_get_width(vin *in)
{
    if (in && in->codec)
        return in->codec->width;
    else
        return 0;
}

// Return teh input video height.

int vin_get_height(vin *in)
{
    if (in && in->codec)
        return in->codec->height;
    else
        return 0;
}

// Attempt to decode the next frame in the input video and store it as 24-bit
// RGB in the given buffer. Return positive if a frame was decoded and zero
// if not. Return negative on error.

bool vin_get_frame(vin *in, void *p)
{
    const uint8_t * const *src = (const uint8_t * const *) in->yuv->data;
          uint8_t * const *dst = (      uint8_t * const *) in->rgb->data;

    AVPacket packet;
    int err = 0;
    int got = 0;

    while (err >= 0)
    {
        if ((err = av_read_frame(in->format, &packet)) >= 0)
        {
            if (packet.stream_index == in->index)
            {
                if ((err = avcodec_decode_video2(in->codec, in->yuv, &got, &packet)) >= 0)
                {
                    if (got)
                    {
                        if (p)
                        {
                            const int w = in->codec->width;
                            const int h = in->codec->height;

                            avpicture_fill((AVPicture *) in->rgb, p, PIX_FMT_RGB24, w, h);
                            sws_scale(in->scale, src, in->yuv->linesize, 0, h,
                                                 dst, in->rgb->linesize);
                        }
                        av_free_packet(&packet);
                        return true;
                    }
                }
                else apperr("Failed to decode frame");
            }
            av_free_packet(&packet);
        }
        else apperr("Failed to read frame");
    }
    return false;
}

//------------------------------------------------------------------------------
