#!/bin/sh

# Select frame number n for extraction

#n=10512
#n=11006
n=11800

# Process each image separately, with a frame offset for synchronization.

./avpan -fcp.sh -ocam1-$n.tif Cam1-1.MP4:$(expr $n - 1305)
./avpan -fcp.sh -ocam2-$n.tif Cam2-1.MP4:$(expr $n - 4044)
./avpan -fcp.sh -ocam3-$n.tif Cam3-1.MP4:$(expr $n - 3291)
./avpan -fcp.sh -ocam4-$n.tif Cam4-1.MP4:$(expr $n - 2461)
./avpan -fcp.sh -ocam5-$n.tif Cam5-1.MP4:$(expr $n -    0)
./avpan -fcp.sh -ocam6-$n.tif Cam6-1.MP4:$(expr $n - 1924)
