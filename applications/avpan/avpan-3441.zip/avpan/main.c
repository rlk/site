// Copyright (c) 2012 Robert Kooima
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>

#include "vin.h"

#define VINMAX 64

//------------------------------------------------------------------------------

#include <tiffio.h>

// Write a TIFF file with the given name.

static void tiffo(const char *name, int w, int h, const void *p)
{
    TIFF *T = 0;

    TIFFSetWarningHandler(0);

    if ((T = TIFFOpen(name, "w")))
    {
        uint32 i, s;

        TIFFSetField(T, TIFFTAG_PHOTOMETRIC,     PHOTOMETRIC_RGB);
        TIFFSetField(T, TIFFTAG_SAMPLEFORMAT,    SAMPLEFORMAT_UINT);
        TIFFSetField(T, TIFFTAG_PLANARCONFIG,    PLANARCONFIG_CONTIG);
        TIFFSetField(T, TIFFTAG_IMAGEWIDTH,      w);
        TIFFSetField(T, TIFFTAG_IMAGELENGTH,     h);
        TIFFSetField(T, TIFFTAG_BITSPERSAMPLE,   8);
        TIFFSetField(T, TIFFTAG_SAMPLESPERPIXEL, 3);

        s = (uint32) TIFFScanlineSize(T);

        for (i = 0; i < h; ++i)
            TIFFWriteScanline(T, (uint8 *) p + i * s, i, 0);

        TIFFWriteDirectory(T);
        TIFFClose(T);
    }
}

//------------------------------------------------------------------------------

#include <regex.h>

// Attempt to match a string to a regular expression pattern. On success,
// return the captured portion of the match in a newly-allocated string.

static char *match(const char *pattern, char *string)
{
    regmatch_t match[2];
    regex_t    regex;

    char *ret = NULL;

    if (regcomp(&regex, pattern, REG_EXTENDED) == 0)
    {
        if (regexec(&regex, string, 2, match, 0) == 0)
        {
            ret = calloc(1, match[1].rm_eo - match[1].rm_so + 1);

            strncpy(ret, string + match[1].rm_so,
                 match[1].rm_eo - match[1].rm_so);
        }
    }
    regfree(&regex);

    return ret;
}

//------------------------------------------------------------------------------

static vin *add(const char *name, long skip, int *maxw, int *maxh)
{
    vin *in;

    if ((in = vin_open(name)))
    {
        int w = vin_get_width(in);
        int h = vin_get_height(in);

        printf("Loaded %s with size %dx%d\n", name, w, h);

        if (*maxw < w)
            *maxw = w;
        if (*maxh < h)
            *maxh = h;

        if (skip)
        {
            printf("Skipping %s to frame %ld\n", name, skip);

            int n = 0;

            while (n < skip && vin_get_frame(in, NULL))
                n++;
        }
    }
    return in;
}

static int run(char *exe, char *out, int vinc, vin **vinv, void *p, int n, int j)
{
    // Construct an command line argument list for the exectution of exe.

    char *arg[vinc + 3];
    char  nam[256];

    arg[0]        = exe;
    arg[1]        = nam;
    arg[vinc + 2] = NULL;

    for (int i = 0; i < vinc; i++)
        arg[2 + i] = strdup(tmpnam(NULL));

    // Loop over all output frame.

    bool loop = true;

    for (int c = 0; c < n && loop; c++)
    {
        printf("Blending frame %d of %d\n", c, n);
        sprintf(nam, out, c);

        // Get a frame from each input video and write it to a temporary TIFF.

        for (int i = 0; i < vinc; i++)

            if (vin_get_frame(vinv[i], p))
                tiffo(arg[2 + i], vin_get_width(vinv[i]),
                                  vin_get_height(vinv[i]), p);
            else
                loop = false;

        // Execute the script.

        int stat;

        if (fork())
            wait(&stat);
        else
        {
            execv(exe, arg);
            exit(1);
        }
    }
    return 0;
}

//------------------------------------------------------------------------------

int main(int argc, char **argv)
{
    vin  *vinv[VINMAX];
    int  vinc =     0;
    char *exe =  NULL;
    char *str =  NULL;
    char *num =  NULL;
    char *out = "out";
    int   w   =     0;
    int   h   =     0;
    int   j   =     1;
    int   n   =     1;
    void *p   =  NULL;

    // Parse all command line arguments and initialize any video files.

    for (int i = 1; i < argc && vinc < VINMAX; i++)
    {
        if      ((str = match("^-f(.*)$", argv[i])))
            exe  = strdup(str);

        else if ((str = match("^-o(.*)$", argv[i])))
            out = strdup(str);

        else if ((num = match("^-n([0-9]*)$", argv[i])))
            n   = strtol(num, NULL, 0);

        else if ((num = match("^-j([0-9]*)$", argv[i])))
            j   = strtol(num, NULL, 0);

        else if ((str = match("^([^:]*):[0-9]*$", argv[i])) &&
                 (num = match("^[^:]*:([0-9]*)$", argv[i])))
            vinv[vinc++] = add(str, strtol(num, NULL, 0), &w, &h);

        else if ((str = match("^([^:]*)$", argv[i])))
            vinv[vinc++] = add(str, 0, &w, &h);

        free(num);
        free(str);
    }

    // Allocate a scratch buffer and run the process.

    if (exe && vinc && (p = malloc(w * h * 3)))
        return run(exe, out, vinc, vinv, p, n, j);
    else
        return 0;
}
