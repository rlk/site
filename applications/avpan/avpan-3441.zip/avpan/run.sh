#!/bin/sh

#n=10300
n=11800

./avpan -fpan.sh -ofh2-%05d.tif -n30 \
	Cam1-1.MP4:$(expr $n - 1305) \
	Cam2-1.MP4:$(expr $n - 4044) \
	Cam3-1.MP4:$(expr $n - 3291) \
	Cam4-1.MP4:$(expr $n - 2461) \
	Cam5-1.MP4:$(expr $n -    0) \
	Cam6-1.MP4:$(expr $n - 1924)
