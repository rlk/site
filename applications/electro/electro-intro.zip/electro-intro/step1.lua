
-------------------------------------------------------------------------------

function create_scene()

    -- Create all entities.

    camera = E.create_camera(E.camera_type_perspective)
    light  = E.create_light(E.light_type_positional)
    floor  = E.create_object("checker.obj")

    -- Create the scene hierarchy.

    E.parent_entity(light, camera)
    E.parent_entity(floor, light)

    -- Position the light and camera within the scene.

    E.set_entity_position(camera, 0, 2, 10)
    E.set_entity_position(light, 0, 10, 5)
end

-------------------------------------------------------------------------------

create_scene()
