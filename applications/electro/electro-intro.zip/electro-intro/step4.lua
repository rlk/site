
-------------------------------------------------------------------------------

function do_timer(dt)
    local turn_rate = -90
    local move_rate =  10
    local distance  =  10

    local joy_x, joy_y = E.get_joystick(0)

    -- Apply the joystick X axis to turn.

    if math.abs(joy_x) > 0.25 then
        E.turn_entity(body, 0, dt * turn_rate * joy_x, 0)
    end

    -- Apply the joystick Y axis to forward motion.

    if math.abs(joy_y) > 0.25 then
        E.move_entity(body, 0, 0, dt * move_rate * joy_y)
    end

    -- Compute the camera position from the car position.

    local cx, cy, cz = E.get_entity_position(camera)
    local px, py, pz = E.get_entity_position(body)
    local vx, vy, vz = E.get_entity_z_vector(body)

    local angle = math.deg(math.atan2(cx - px, cz - pz))

    E.set_entity_rotation(camera, 0, angle, 0)
    E.set_entity_position(camera, px + vx * distance,
                                  py + vy * distance + 2,
                                  pz + vz * distance)
    return true
end

function create_car()

    -- Load all models.

    body  = E.create_object("body.obj")

    tire1 = E.create_object("tire.obj")
    tire2 = E.create_clone(tire1)
    tire3 = E.create_clone(tire1)
    tire4 = E.create_clone(tire1)

    -- Create the car hierarchy.

    E.parent_entity(tire1, body)
    E.parent_entity(tire2, body)
    E.parent_entity(tire3, body)
    E.parent_entity(tire4, body)

    -- Position the tires with respect to the body.

    E.set_entity_position(tire1, -0.85, -0.75, -1.25)
    E.set_entity_position(tire2,  0.85, -0.75, -1.25)
    E.set_entity_position(tire3, -0.85, -0.75,  1.30)
    E.set_entity_position(tire4,  0.85, -0.75,  1.30)

    -- Add the car to the scene.

    E.parent_entity(body, light)

    E.set_entity_position(body, 3, 1.1, 0)
    E.set_entity_rotation(body, 0, 90, 0)
end

function create_scene()

    -- Create all entities.

    camera = E.create_camera(E.camera_type_perspective)
    light  = E.create_light(E.light_type_positional)
    floor  = E.create_object("checker.obj")

    -- Create the scene hierarchy.

    E.parent_entity(light, camera)
    E.parent_entity(floor, light)

    -- Position the light and camera within the scene.

    E.set_entity_position(camera, 0, 2, 10)
    E.set_entity_position(light, 0, 10, 5)

    E.set_entity_scale(floor, 10, 10, 10)
end

-------------------------------------------------------------------------------

create_scene()
create_car()

E.enable_timer(true)
